#!/usr/bin/env python3
"""
Gradle-free APK build for the tvhome launcher, driven by the raw Android SDK tools.

  aapt2 (native) -> javac (one-shot) -> d8 (one-shot) -> zipalign + apksigner

No Gradle daemon, no dependency resolution, no network: the two AndroidX dependencies
(recyclerview, dynamicanimation + transitives) are taken from the local Gradle cache
left by earlier builds. Output: app-release-py.apk in the project root.
"""
import glob
import os
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LAUNCHER = os.path.join(ROOT, "launcher")
SDK = os.environ["ANDROID_SDK_ROOT"]
BT = os.path.join(SDK, "build-tools", "34.0.0")
PLATFORM_JAR = os.path.join(SDK, "platforms", "android-34", "android.jar")
JDK = os.environ["JAVA_HOME"]
JAVA = os.path.join(JDK, "bin", "java.exe")
JAVAC = os.path.join(JDK, "bin", "javac.exe")
AAPT2 = os.path.join(BT, "aapt2.exe")
ZIPALIGN = os.path.join(BT, "zipalign.exe")
D8_JAR = os.path.join(BT, "lib", "d8.jar")
APKSIGNER_JAR = os.path.join(BT, "lib", "apksigner.jar")
KEYSTORE = os.environ["TVHOME_KEYSTORE"]
WORK = os.path.join(ROOT, "build-py")

APP_PKG = "com.gathin.tvhome"
MIN_SDK = "26"
TARGET_SDK = "34"


def run(cmd, **kw):
    print("$ " + " ".join(cmd[:6]) + (" ..." if len(cmd) > 6 else ""))
    r = subprocess.run(cmd, **kw)
    if r.returncode != 0:
        raise SystemExit(f"command failed ({r.returncode}): {cmd[0]}")


def main():
    for p in (AAPT2, ZIPALIGN, PLATFORM_JAR, JAVAC, D8_JAR, APKSIGNER_JAR, KEYSTORE):
        if not os.path.exists(p):
            raise SystemExit(f"missing: {p}")

    # Fresh work dir (keep nothing from previous attempts).
    if os.path.isdir(WORK):
        shutil.rmtree(WORK)
    os.makedirs(os.path.join(WORK, "compiled"), exist_ok=True)
    os.makedirs(os.path.join(WORK, "gen"), exist_ok=True)

    # ---- 1. Dependencies from the local Gradle cache (androidx only) ----
    cache = os.path.join(os.environ.get("GRADLE_USER_HOME", os.path.expanduser("~/.gradle")), "caches", "modules-2", "files-2.1")
    # Path layout: cache\group\artifact\version\hash\file  -> group is 4 dirnames up.
    # Group dirs on disk keep the dots (androidx.recyclerview), so glob and filter on the group.
    def group_of(p):
        for _ in range(4):
            p = os.path.dirname(p)
        return os.path.basename(p)

    def is_dep(p):
        return group_of(p).startswith("androidx") \
            and not os.path.basename(p).startswith("databinding")  # build-time only

    aars = sorted(p for p in glob.glob(os.path.join(cache, "**", "*.aar"), recursive=True) if is_dep(p))
    jars = sorted(p for p in glob.glob(os.path.join(cache, "**", "*.jar"), recursive=True) if is_dep(p))
    if not any("recyclerview" in a for a in aars) or not any("dynamicanimation" in a for a in aars):
        raise SystemExit("recyclerview/dynamicanimation not found in the Gradle cache")
    print(f"deps: {len(aars)} aar + {len(jars)} jar from local cache")

    dep_jars = []
    dep_res = []  # (name, resdir)
    for aar in aars:
        name = os.path.basename(aar)[:-4]
        ext = os.path.join(WORK, "ext", name)
        os.makedirs(ext, exist_ok=True)
        with zipfile.ZipFile(aar) as z:
            z.extractall(ext)
        cj = os.path.join(ext, "classes.jar")
        if os.path.exists(cj):
            dep_jars.append(cj)
        res = os.path.join(ext, "res")
        if os.path.isdir(res) and os.listdir(res):
            dep_res.append((name, res))
    dep_jars.extend(jars)
    # Kotlin stdlib: several AARs ship Kotlin code that references kotlin.jvm.internal.Intrinsics.
    kotlin = sorted(glob.glob(os.path.join(cache, "org.jetbrains.kotlin", "kotlin-stdlib",
                                            "*", "*", "kotlin-stdlib-*.jar")))
    if kotlin:
        dep_jars.append(kotlin[-1])  # newest version in the cache
    dep_jars = sorted(set(dep_jars))

    # ---- 2. Manifest: inject the AGP namespace + resolve the ${applicationId} placeholder ----
    src = open(os.path.join(LAUNCHER, "app", "src", "main", "AndroidManifest.xml"), encoding="utf-8").read()
    src = src.replace("${applicationId}", APP_PKG)
    src = re.sub(r"<manifest ", f'<manifest package="{APP_PKG}" ', src, count=1)
    manifest = os.path.join(WORK, "AndroidManifest.xml")
    open(manifest, "w", encoding="utf-8").write(src)

    # ---- 3. aapt2 compile (native binary, no JVM) ----
    def compile_res(resdir, outzip, label):
        print(f"aapt2 compile {label}")
        run([AAPT2, "compile", "--dir", resdir, "-o", outzip])

    flat_zips = []
    for name, res in dep_res:
        z = os.path.join(WORK, "compiled", name + ".zip")
        compile_res(res, z, name)
        flat_zips.append(z)
    app_res = os.path.join(LAUNCHER, "app", "src", "main", "res")
    app_zip = os.path.join(WORK, "compiled", "app.zip")
    compile_res(app_res, app_zip, "app")
    flat_zips.append(app_zip)  # app last: app resources win on conflict

    # ---- 4. aapt2 link -> base.apk (resources.arsc, manifest, res/) + R.java ----
    base = os.path.join(WORK, "base.apk")
    gen = os.path.join(WORK, "gen")
    print("aapt2 link")
    run([AAPT2, "link", "-o", base, "-I", PLATFORM_JAR, "--manifest", manifest,
         "--java", gen, "--min-sdk-version", MIN_SDK, "--target-sdk-version", TARGET_SDK,
         "--version-code", "6", "--version-name", "2.5", "--auto-add-overlay"] + flat_zips)

    # ---- 4b. Library R classes. AAR code references its own R (e.g. androidx.recyclerview.R$attr);
    # AGP generates one per library. The app's R.java holds the full merged table with the exact
    # runtime values, so a per-package copy (package line rewritten) is correct for every library.
    r_java = os.path.join(gen, *APP_PKG.split("."), "R.java")
    if not os.path.exists(r_java):
        raise SystemExit(f"R.java not generated: {r_java}")
    app_r = open(r_java, encoding="utf-8").read()
    lib_pkgs = []
    for aar in aars:
        mf = os.path.join(WORK, "ext", os.path.basename(aar)[:-4], "AndroidManifest.xml")
        if not os.path.exists(mf):
            continue
        m = re.search(r'package="([^"]+)"', open(mf, encoding="utf-8").read())
        if m and m.group(1) != APP_PKG and m.group(1) not in lib_pkgs:
            lib_pkgs.append(m.group(1))
    for pkg in lib_pkgs:
        d = os.path.join(gen, *pkg.split("."))
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "R.java"), "w", encoding="utf-8") as f:
            f.write(app_r.replace(f"package {APP_PKG};", f"package {pkg};", 1))
    print(f"library R classes: {', '.join(lib_pkgs)}")

    # ---- 5. javac (one-shot, a few seconds) ----
    java_files = sorted(glob.glob(os.path.join(LAUNCHER, "app", "src", "main", "java", "**", "*.java"),
                                 recursive=True))
    classes = os.path.join(WORK, "classes")
    cp = PLATFORM_JAR + os.pathsep + os.pathsep.join(dep_jars)
    print(f"javac {len(java_files) + 1} files")
    lib_r = [os.path.join(gen, *p.split("."), "R.java") for p in lib_pkgs]
    run([JAVAC, "-source", "17", "-target", "17", "-encoding", "UTF-8", "-nowarn",
         "-cp", cp, "-d", classes] + java_files + [r_java] + lib_r)

    # ---- 6. d8 (one-shot) -> classes.dex (+ more if multidex) ----
    app_jar = os.path.join(WORK, "app-classes.jar")
    with zipfile.ZipFile(app_jar, "w") as z:
        for root, _, files in os.walk(classes):
            for f in files:
                p = os.path.join(root, f)
                z.write(p, os.path.relpath(p, classes).replace("\\", "/"))
    dexout = os.path.join(WORK, "dex")
    os.makedirs(dexout, exist_ok=True)
    print("d8")
    run([JAVA, "-Xmx2g", "-cp", D8_JAR, "com.android.tools.r8.D8", "--release", "--min-api", MIN_SDK,
         "--lib", PLATFORM_JAR, "--output", dexout] + [app_jar] + dep_jars)
    dexes = sorted(glob.glob(os.path.join(dexout, "classes*.dex")))
    if not dexes:
        raise SystemExit("d8 produced no dex files")
    print(f"dex: {', '.join(os.path.basename(d) for d in dexes)}")

    # ---- 7. Package: base.apk + dex + assets ----
    unsigned = os.path.join(WORK, "unsigned.apk")
    shutil.copy(base, unsigned)
    with zipfile.ZipFile(unsigned, "a") as z:
        for d in dexes:
            z.write(d, os.path.basename(d))
        assets = os.path.join(LAUNCHER, "app", "src", "main", "assets")
        if os.path.isdir(assets):
            n = 0
            for root, _, files in os.walk(assets):
                for f in files:
                    p = os.path.join(root, f)
                    z.write(p, "assets/" + os.path.relpath(p, assets).replace("\\", "/"))
                    n += 1
            print(f"assets: {n} files")

    # ---- 8. zipalign + apksigner (debug keystore, same key as the installed build) ----
    aligned = os.path.join(WORK, "aligned.apk")
    run([ZIPALIGN, "-f", "4", unsigned, aligned])
    out = os.path.join(ROOT, "app-release-py.apk")
    run([JAVA, "-cp", APKSIGNER_JAR, "com.android.apksigner.ApkSignerTool", "sign",
         "--ks", KEYSTORE, "--ks-pass", "env:TVHOME_KEYSTORE_PASSWORD",
         "--ks-key-alias", os.environ["TVHOME_KEY_ALIAS"], "--key-pass", "env:TVHOME_KEYSTORE_PASSWORD",
         "--out", out, aligned])
    run([JAVA, "-cp", APKSIGNER_JAR, "com.android.apksigner.ApkSignerTool", "verify",
         "--print-certs", out])
    print(f"\nDONE: {out}  ({os.path.getsize(out) // 1024} KB)")


if __name__ == "__main__":
    main()
