package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.provider.Settings;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.database.Cursor;
import android.provider.DocumentsContract;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * "TV Setup" screen, reached from the Settings panel: the four self-service actions the TV owner can
 * run without a PC. The launcher is the device owner (set once over adb), so it may re-disable the
 * bloatware packages and read the debloat list. Add/rearrange edit the dock in config.json; the
 * debloat re-applies a package list (built-in, or a file picked from a USB stick via the document
 * picker); the factory reset hands off to the TV's own reset screen.
 */
public final class TVSetupActivity extends Activity {

    private static final int REQ_USB = 1001;
    /**
     * The built-in debloat list, exposed for the boot safety net (DebloatBootReceiver) so there is a
     * single source of truth. Returns the array itself (treat as read-only).
     */
    public static String[] debloatList() { return DEBLOAT; }

    /** The debloat: the bloatware packages disabled during setup, one per line. */
    private static final String[] DEBLOAT = {
            "android.autoinstalls.config.google.gtvpai",
            "com.android.adservices.api",
            "com.android.federatedcompute.services",
            "com.android.ondevicepersonalization.services",
            "com.android.tv.feedbackconsent",
            "com.app.mlounge",
            "com.google.android.feedback",
            "com.google.android.partnersetup",
            "com.google.android.play.games",
            "com.google.android.videos",
            "com.google.android.tungsten.setupwraith",
            "com.google.android.youtube.tvmusic",
            "com.mediatek.airplaydaemon",
            "com.tcl.airplay2",
            "com.tcl.channelplus",
            "com.tcl.dashboard",
            "com.tcl.esticker",
            "com.tcl.exhibit",
            "com.tcl.guard",
            "com.tcl.interactive",
            "com.tcl.logkit",
            "com.tcl.magiconnectfree",
            "com.tcl.messagebox",
            "com.tcl.ocean.instructions",
            "com.tcl.partnercustomizer",
            "com.tcl.repairguide",
            "com.tcl.smartalexa",
            "com.tcl.ttvs",
            "com.tcl.tv.tclhome_passive",
            "com.tcl.usercenter",
            "com.tcl.waterfall.overseas",
            "com.google.android.katniss",
            "com.google.android.tv.remote.service",
    };

    /** Path of the shell-level executor script on the TV (world-writable tmp dir). */
    private static final String DAEMON_PATH = "/data/local/tmp/cys-daemon.sh";
    private static final String DAEMON_PATH_NEW = "/data/local/tmp/cys-daemon.d/cys-daemon.sh";
    private static final Object DAEMON_START_LOCK = new Object();
    private static final java.util.concurrent.atomic.AtomicBoolean DAEMON_BUTTON_BUSY = new java.util.concurrent.atomic.AtomicBoolean();
    /**
     * Embedded copy of the executor script: the "Start daemon" button restores it if it is
     * missing, so the TV can always bring the Reapply/Reset executor back up without a PC.
     */
    private static final String DAEMON_SCRIPT = String.join("\n",
            "#!/system/bin/sh",
            "# cys-daemon - shell-level executor for package state changes (Reapply / Reset).",
            "# The launcher app (uid 10108) cannot change package state (signature-level",
            "# CHANGE_COMPONENT_ENABLED_STATE). This daemon runs as shell (uid 2000) and can.",
            "# Files (in the app external dir): pkg-cmd.txt (in), pkg-list.txt (in),",
            "#   pkg-result.txt (out), daemon-ping.txt (out heartbeat),",
            "#   daemon-uid.txt (out: the uid this daemon runs as, written at start).",
            "# Counting is STATE-BASED (verified after), because pm returns non-zero when a",
            "# package is already in the target state or not installed.",
            "FILES=/storage/emulated/0/Android/data/com.gathin.tvhome/files",
            "CMD=\"$FILES/pkg-cmd.txt\"",
            "RESULT=\"$FILES/pkg-result.txt\"",
            "PING=\"$FILES/daemon-ping.txt\"",
            "UIDF=\"$FILES/daemon-uid.txt\"",
            "LIST_APP=\"$FILES/pkg-list.txt\"",
            "LIST_BUILTIN=/data/local/tmp/debloat-builtin.txt",
            "BUILD_LIST=\"$FILES/build-list.txt\"",
            "TVHOME=\"com.gathin.tvhome/.MainActivity\"",
            "STOCK=\"com.google.android.apps.tv.launcherx/.home.HomeActivity\"",
            "# VETTED_LIST: the built-in 33-entry debloat allowlist (kept in sync with",
            "# KitPolicy.VETTED / DEBLOAT). The scoped Reset re-enables exactly these + launcher.",
            "VETTED_LIST='android.autoinstalls.config.google.gtvpai",
            "com.android.adservices.api",
            "com.android.federatedcompute.services",
            "com.android.ondevicepersonalization.services",
            "com.android.tv.feedbackconsent",
            "com.app.mlounge",
            "com.google.android.feedback",
            "com.google.android.partnersetup",
            "com.google.android.play.games",
            "com.google.android.videos",
            "com.google.android.tungsten.setupwraith",
            "com.google.android.youtube.tvmusic",
            "com.mediatek.airplaydaemon",
            "com.tcl.airplay2",
            "com.tcl.channelplus",
            "com.tcl.dashboard",
            "com.tcl.esticker",
            "com.tcl.exhibit",
            "com.tcl.guard",
            "com.tcl.interactive",
            "com.tcl.logkit",
            "com.tcl.magiconnectfree",
            "com.tcl.messagebox",
            "com.tcl.ocean.instructions",
            "com.tcl.partnercustomizer",
            "com.tcl.repairguide",
            "com.tcl.smartalexa",
            "com.tcl.ttvs",
            "com.tcl.tv.tclhome_passive",
            "com.tcl.usercenter",
            "com.tcl.waterfall.overseas",
            "com.google.android.katniss",
            "com.google.android.tv.remote.service'",
            "# Self-report who we are: the launcher reads this to tell the owner whether the",
            "# daemon has full shell rights (uid 2000) or only app rights (uid 10108, started",
            "# from the TV Setup menu). pm package changes need the shell uid.",
            "# w <file> <text>: write a protocol file world-writable. ATOMIC: write to a temp",
            "# file then mv into place, so a reader (the launcher app, another uid) sees either",
            "# the complete file or nothing - never a partial write. chmod 666 so BOTH uids that",
            "# can start this daemon (shell 2000 / app 10108) can always write it, regardless of",
            "# which one created it first (a 644 file owned by the other uid is not writable, but",
            "# a file in the app's own dir can be deleted by the app).",
            "w() { local t=\"$1.tmp.$$\"; printf '%s' \"$2\" > \"$t\" 2>/dev/null && chmod 666 \"$t\" 2>/dev/null && mv -f \"$t\" \"$1\" 2>/dev/null; }",
            "# valid_p: a list entry may only look like a lowercase package name (no shell metachars).",
            "valid_p() { case \"$1\" in \"\"|*[!a-zA-Z0-9_.]*) return 1;; esac; case \"$1\" in .*|*.) return 1;; esac; case \"$1\" in *..*) return 1;; esac; case \"$1\" in [0-9]*) return 1;; esac; return 0; }",
            "w \"$UIDF\" \"$(id -u)\"",
            "while true; do",
            "  w \"$PING\" \"$(date +%s)\"",
            "  # Report our uid every loop: the launcher's status line must always reflect the",
            "  # daemon that is actually running (it can be replaced by one of the other uid).",
            "  w \"$UIDF\" \"$(id -u)\"",
            "  if [ -f \"$CMD\" ]; then",
            "    c=$(cat \"$CMD\" 2>/dev/null)",
            "    rm -f \"$CMD\"",
            "    ts=$(date +%s)",
            "    if [ \"$c\" = \"apply\" ]; then",
            "      listfile=\"$LIST_BUILTIN\"",
            "      [ -f \"$LIST_APP\" ] && listfile=\"$LIST_APP\"",
            "      # Validate the WHOLE list before any mutation: one malformed entry rejects",
            "      # the run (the GUI already format-checks and confirms non-vetted entries).",
            "      bad=0",
            "      if [ -f \"$listfile\" ]; then",
            "        while IFS= read -r p || [ -n \"$p\" ]; do",
            "          p=$(printf '%s' \"$p\" | tr -d '\\r')",
            "          [ -z \"$p\" ] && continue",
            "          case \"$p\" in \"#\"*) continue;; esac",
            "          valid_p \"$p\" || bad=1",
            "        done < \"$listfile\"",
            "      fi",
            "      if [ \"$bad\" = 1 ]; then",
            "        w \"$RESULT\" \"apply ts=$ts rejected=1\"",
            "      else",
            "      if [ -f \"$listfile\" ]; then",
            "        while IFS= read -r p || [ -n \"$p\" ]; do",
            "          p=$(printf '%s' \"$p\" | tr -d '\\r')",
            "          [ -z \"$p\" ] && continue",
            "          case \"$p\" in \"#\"*) continue;; esac",
            "          pm disable-user --user 0 \"$p\" </dev/null >/dev/null 2>&1",
            "        done < \"$listfile\"",
            "      fi",
            "      pm disable-user --user 0 com.google.android.apps.tv.launcherx </dev/null >/dev/null 2>&1",
            "      cmd package set-home-activity --user 0 \"$TVHOME\" </dev/null >/dev/null 2>&1",
            "      disabled_list=$(pm list packages -d 2>/dev/null)",
            "      ok=0",
            "      total=0",
            "      if [ -f \"$listfile\" ]; then",
            "        while IFS= read -r p || [ -n \"$p\" ]; do",
            "          p=$(printf '%s' \"$p\" | tr -d '\\r')",
            "          [ -z \"$p\" ] && continue",
            "          case \"$p\" in \"#\"*) continue;; esac",
            "          total=$((total+1))",
            "          if printf '%s\\n' \"$disabled_list\" | grep -Fxq -- \"package:$p\"; then ok=$((ok+1)); fi",
            "        done < \"$listfile\"",
            "      fi",
            "      fail=$((total-ok))",
            "      # Record the applied set (listfile + launcher) so Reset can undo exactly this.",
            "      { if [ -f \"$listfile\" ]; then while IFS= read -r p || [ -n \"$p\" ]; do p=$(printf '%s' \"$p\" | tr -d '\\r'); [ -z \"$p\" ] && continue; case \"$p\" in \"#\"*) continue;; esac; printf '%s\\n' \"$p\"; done < \"$listfile\"; fi; printf '%s\\n' com.google.android.apps.tv.launcherx; } > \"$BUILD_LIST\" 2>/dev/null",
            "      w \"$RESULT\" \"apply ts=$ts ok=$ok fail=$fail home=tvhome\"",
            "      fi",
            "    elif [ \"$c\" = \"reset\" ]; then",
            "      # Intended reset targets = the packages this build disabled (recorded build",
            "      # list, which also covers owner-confirmed custom entries). Fall back to the",
            "      # vetted list + stock launcher for the initial migration (no recorded list",
            "      # yet). Unrelated disabled packages (the owner's own) are preserved and are",
            "      # never counted as failures.",
            "      targets=\"\"",
            "      if [ -f \"$BUILD_LIST\" ]; then",
            "        while IFS= read -r p || [ -n \"$p\" ]; do",
            "          p=$(printf '%s' \"$p\" | tr -d '\\r')",
            "          [ -z \"$p\" ] && continue",
            "          case \"$p\" in \"#\"*) continue;; esac",
            "          valid_p \"$p\" || continue",
            "          targets=\"$targets $p\"",
            "        done < \"$BUILD_LIST\"",
            "      fi",
            "      [ -n \"$targets\" ] || targets=\"$VETTED_LIST com.google.android.apps.tv.launcherx\"",
            "      for p in $targets; do",
            "        pm enable --user 0 \"$p\" </dev/null >/dev/null 2>&1",
            "      done",
            "      cmd package set-home-activity --user 0 \"$STOCK\" </dev/null >/dev/null 2>&1",
            "      disabled_list=$(pm list packages -d 2>/dev/null)",
            "      ok=0",
            "      fail=0",
            "      for p in $targets; do",
            "        if printf '%s\\n' \"$disabled_list\" | grep -Fxq -- \"package:$p\"; then fail=$((fail+1)); else ok=$((ok+1)); fi",
            "      done",
            "      w \"$RESULT\" \"reset ts=$ts ok=$ok fail=$fail home=stock\"",
            "    elif [ \"$c\" = \"usb\" ]; then",
            "      # USB kit auto-apply. Mounted removable (public) volume roots are derived",
            "      # from the authoritative 'sm list-volumes public' metadata (on this TV:",
            "      # 'public:8,1 mounted ABCD-1234' -> field 3 is the volume uuid -> /storage/<uuid>).",
            "      # The kit is looked up ONLY at the two known build-folder locations - no broad",
            "      # /storage or /mnt scan, so a matching file on shared internal storage never",
            "      # counts as a kit. Kit files must be regular files (no symlink escape) and",
            "      # canonicalize inside their volume root (firmware /storage mount aliases pass).",
            "      usb_roots() {",
            "        sm list-volumes public 2>/dev/null | while IFS= read -r line; do",
            "          [ -n \"$line\" ] || continue",
            "          set -- $line",
            "          [ \"$2\" = \"mounted\" ] || continue",
            "          uuid=\"$3\"",
            "          case \"$uuid\" in *[!a-zA-Z0-9_-]*|\"\") continue;; esac",
            "          printf '/storage/%s\\n' \"$uuid\"",
            "        done",
            "      }",
            "      canon() { r=$(realpath \"$1\" 2>/dev/null); [ -n \"$r\" ] && printf '%s' \"$r\"; return 0; }",
            "      checkfile() { p=\"$1\"; root=\"$2\"; [ -n \"$p\" ] || return 0; [ -f \"$p\" ] || return 1; [ -L \"$p\" ] && return 1; f=$(canon \"$p\"); [ -n \"$f\" ] || return 1; r=$(canon \"$root\"); [ -n \"$r\" ] || return 1; case \"$f\" in \"$r\"|\"$r\"/*) return 0;; esac; return 1; }",
            "      kitdir=\"\"",
            "      volume_root=\"\"",
            "      for root in $(usb_roots); do",
            "        [ -d \"$root\" ] || continue",
            "        if [ -f \"$root/CLEANYOURTV-USB/AUTOAPPLY\" ]; then",
            "          kitdir=\"$root/CLEANYOURTV-USB\"; volume_root=\"$root\"; break",
            "        fi",
            "        if [ -f \"$root/CLEANYOURTV-USB/CLEANYOURTV-USB/AUTOAPPLY\" ]; then",
            "          kitdir=\"$root/CLEANYOURTV-USB/CLEANYOURTV-USB\"; volume_root=\"$root\"; break",
            "        fi",
            "      done",
            "      if [ -z \"$kitdir\" ] || [ ! -f \"$kitdir/debloat.txt\" ]; then",
            "        w \"$RESULT\" \"usb ts=$ts none=1\"",
            "        exit 0",
            "      fi",
            "      # Durable completion record for the USB report (survives the APK self-update",
            "      # killing the app): the shell commits it only after the operation really ended.",
            "      uuuid=\"${volume_root#/storage/}\"",
            "      usb_fail() { w \"$RESULT\" \"usb ts=$ts $1\"; w \"$FILES/usb-txn-$ts.json\" \"v=1|src=auto|vol=$uuuid|status=failed|ok=-|fail=-|reason=$1|ts=$ts|consumed=0\"; exit 0; }",
            "      checkfile \"$kitdir/AUTOAPPLY\" \"$volume_root\" || usb_fail rejected=path",
            "      checkfile \"$kitdir/debloat.txt\" \"$volume_root\" || usb_fail rejected=path",
            "      apkfile=\"\"",
            "      [ -f \"$kitdir/app-release-py.apk\" ] && apkfile=\"$kitdir/app-release-py.apk\"",
            "      checkfile \"$apkfile\" \"$volume_root\" || usb_fail rejected=path",
            "      cfgfile=\"\"",
            "      [ -f \"$kitdir/config.json\" ] && cfgfile=\"$kitdir/config.json\"",
            "      checkfile \"$cfgfile\" \"$volume_root\" || usb_fail rejected=path",
            "      wpfile=\"\"",
            "      [ -f \"$kitdir/wallpaper.jpg\" ] && wpfile=\"$kitdir/wallpaper.jpg\"",
            "      checkfile \"$wpfile\" \"$volume_root\" || usb_fail rejected=path",
            "      dd=/data/local/tmp/cys-daemon.d",
            "      [ ! -L \"$dd\" ] && [ \"$(stat -c %u \"$dd\" 2>/dev/null)\" = 2000 ] || usb_fail rejected=stage",
            "      umask 077",
            "      stage=\"$dd/usb-stage-$$\"",
            "      mkdir \"$stage\" 2>/dev/null || usb_fail rejected=stage",
            "      trap 'rm -f \"$FILES/usb_in_progress\"; rm -rf \"$stage\"' EXIT",
            "      cp \"$kitdir/debloat.txt\" \"$stage/debloat.txt\" 2>/dev/null || usb_fail rejected=copy",
            "      [ -s \"$stage/debloat.txt\" ] && [ \"$(stat -c %s \"$stage/debloat.txt\")\" -le 65536 ] || usb_fail rejected=list",
            "      for name in app-release-py.apk config.json wallpaper.jpg; do",
            "        if [ -f \"$kitdir/$name\" ]; then",
            "          size=$(stat -c %s \"$kitdir/$name\" 2>/dev/null)",
            "          case \"$size\" in ''|*[!0-9]*) usb_fail rejected=size;; esac",
            "          [ \"$size\" -le 104857600 ] || { usb_fail rejected=size; }",
            "          cp \"$kitdir/$name\" \"$stage/$name\" 2>/dev/null || usb_fail rejected=copy",
            "          chmod 600 \"$stage/$name\" || usb_fail rejected=stage",
            "        fi",
            "      done",
            "      kitdir=\"$stage\"",
            "      apkfile=\"\"; cfgfile=\"\"; wpfile=\"\"",
            "      [ -f \"$stage/app-release-py.apk\" ] && apkfile=\"$stage/app-release-py.apk\"",
            "      [ -f \"$stage/config.json\" ] && cfgfile=\"$stage/config.json\"",
            "      [ -f \"$stage/wallpaper.jpg\" ] && wpfile=\"$stage/wallpaper.jpg\"",
            "      # Whole-list rejection: EVERY debloat.txt entry must exactly match the immutable",
            "      # embedded vetted allowlist. One unknown entry aborts BEFORE any install/copy/disable.",
            "      bad=0",
            "      while IFS= read -r p || [ -n \"$p\" ]; do",
            "        p=$(printf '%s' \"$p\" | tr -d '\\r')",
            "        [ -z \"$p\" ] && continue",
            "        case \"$p\" in \"#\"*) continue;; esac",
            "        printf '%s\\n' \"$VETTED_LIST\" | grep -Fxq -- \"$p\" || bad=1",
            "      done < \"$kitdir/debloat.txt\"",
            "      if [ \"$bad\" = 1 ]; then usb_fail rejected=list; fi",
            "      # The package update may kill/restart the launcher. Defer its auto-apply until",
            "      # this shell-owned operation finishes; this timestamp is only a retry hint.",
            "      w \"$FILES/usb_in_progress\" \"$(date +%s)\"",
            "      if [ -n \"$apkfile\" ]; then",
            "        # Android checks the actual expected package AND its installed signing identity.",
            "        # A substring in manifest metadata cannot authorize a different package.",
            "        if ! pm install -r --pkg com.gathin.tvhome \"$apkfile\" >/dev/null 2>&1; then usb_fail rejected=apk_install; fi",
            "      fi",
            "      if [ -n \"$cfgfile\" ]; then cp \"$cfgfile\" \"$FILES/config.json\" 2>/dev/null || usb_fail error=config_copy; fi",
            "      if [ -n \"$wpfile\" ]; then cp \"$wpfile\" \"$FILES/wallpaper.jpg\" 2>/dev/null || usb_fail error=wallpaper_copy; fi",
            "      printf 'usb-%s' \"$ts\" > \"$FILES/theme_revision\" 2>/dev/null",
            "      listfile=\"$kitdir/debloat.txt\"",
            "      while IFS= read -r p || [ -n \"$p\" ]; do",
            "        p=$(printf '%s' \"$p\" | tr -d '\\r')",
            "        [ -z \"$p\" ] && continue",
            "        case \"$p\" in \"#\"*) continue;; esac",
            "        pm disable-user --user 0 \"$p\" </dev/null >/dev/null 2>&1",
            "      done < \"$listfile\"",
            "      pm disable-user --user 0 com.google.android.apps.tv.launcherx </dev/null >/dev/null 2>&1",
            "      cmd package set-home-activity --user 0 \"$TVHOME\" </dev/null >/dev/null 2>&1",
            "      { while IFS= read -r p || [ -n \"$p\" ]; do p=$(printf '%s' \"$p\" | tr -d '\\r'); [ -z \"$p\" ] && continue; case \"$p\" in \"#\"*) continue;; esac; printf '%s\\n' \"$p\"; done < \"$listfile\"; printf '%s\\n' com.google.android.apps.tv.launcherx; } > \"$BUILD_LIST\" 2>/dev/null",
            "      disabled_list=$(pm list packages -d 2>/dev/null)",
            "      ok=0",
            "      total=0",
            "      while IFS= read -r p || [ -n \"$p\" ]; do",
            "        p=$(printf '%s' \"$p\" | tr -d '\\r')",
            "        [ -z \"$p\" ] && continue",
            "        case \"$p\" in \"#\"*) continue;; esac",
            "        total=$((total+1))",
            "        if printf '%s\\n' \"$disabled_list\" | grep -Fxq -- \"package:$p\"; then ok=$((ok+1)); fi",
            "      done < \"$listfile\"",
            "      fail=$((total-ok))",
            "      # Commit markers from the surviving shell, not the app process killed by install.",
            "      w \"$FILES/usb_applied\" \"\"",
            "      w \"$FILES/build_applied\" \"\"",
            "      # Commit one fresh receipt per apply.\n            w \"$FILES/usb-txn-$ts.json\" \"v=1|src=auto|vol=$uuuid|status=completed|ok=$ok|fail=$fail|reason=-|ts=$ts|consumed=0\"",
            "      w \"$RESULT\" \"usb ts=$ts ok=$ok fail=$fail home=tvhome\"",
            "      am start -n \"$TVHOME\" </dev/null >/dev/null 2>&1",
            "      exit 0",
            "    else",
            "      w \"$RESULT\" \"unknown ts=$ts cmd=$c\"",
            "    fi",
            "  fi",
            "  sleep 1",
            "done",
            "");

    private File configFile;
    private LinearLayout rows;
    private int pendingRearrange = -1;   // pick-and-place: the dock index currently "picked up"
    private LinearLayout lastRow;        // the row most recently added by addRow()
    private TextView lastRowDesc;        // its description line
    private TextView daemonRowDesc;      // the "Start daemon" row's description (live status)

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        configFile = new File(getExternalFilesDir(null), Config.FILE_NAME);

        // Routed here by MainActivity after a USB Reapply: the durable transaction record
        // (usb-transaction.json) survives the APK self-update, so the report opens even when
        // the process that started the operation was killed by it.
        // A finished (or failed) USB Reapply leaves a durable transaction record. Route it to the
        // completion report here, not only when MainActivity passed the usb_report extra: after a
        // Reset the stock launcher is Home, so MainActivity may never resume and the remote
        // settings key (this activity) is the owner's entry point to the report.
        sweepOldUsbTxn();
        if (showUsbReport()) return;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0B0F14);
        root.setPadding(dp(90), dp(60), dp(90), dp(60));

        TextView title = new TextView(this);
        title.setText("TV Setup");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(30);
        title.setPadding(0, 0, 0, dp(28));
        root.addView(title);

        rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(rows);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // All rows do not fit on a 1080p screen: follow the focus so the hovered row is
        // always fully visible - the owner never presses OK on something they cannot see.
        rows.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) return;
            View focused = rows.getFocusedChild();
            if (focused == null) return;
            int h = scroll.getHeight();
            if (h <= 0) return;   // not laid out yet
            int margin = dp(10);
            int top = focused.getTop();
            int bottom = focused.getBottom();
            int y = scroll.getScrollY();
            if (top < y + margin) scroll.smoothScrollTo(0, top - margin);
            else if (bottom > y + h - margin) scroll.smoothScrollTo(0, bottom - h + margin);
        });

        // The menu mirrors the build state: with the build applied, the full customization menu;
        // after "Reset Debloat settings" only the two buttons that keep the TV self-sufficient:
        // Reapply (built-in on the TV / from a USB stick) and Reset again.
        // A dedicated marker (not the self-healing config.json) is the reliable "build active"
        // flag: Reapply creates it, Reset deletes it, and the launcher's config self-heal never
        // touches it. After a Reset the menu collapses to just Reapply + Reset.
        boolean buildActive = new File(configFile.getParentFile(), "build_applied").isFile();
        if (buildActive) {
addRow("Add app to home screen", "Pick an installed app to pin to the dock - the dock grows to 5 slots for a 5th app",
                R.drawable.ic_apps, v -> addApp());
addRow("Remove app from home screen", "Unpin a dock app - the dock shrinks back to 4 slots below 5 apps",
                R.drawable.ic_swap_vert, v -> removeApp());
addRow("Rearrange home screen apps", "Change the order of the dock apps",
                R.drawable.ic_swap_vert, v -> rearrange());
addRow("Themes", "Pick a home screen theme",
                R.drawable.ic_settings, v -> pickTheme());
        }
addRow("Reapply Debloat and Tweaks", "Re-apply the full build - debloat, theme, tweaks and Live TV. Built-in, or from a folder on a USB stick",
                R.drawable.ic_settings, v -> reapplyDebloat());
        addRow("Reset Debloat settings", "Undo the debloat build: re-enable packages, stock home screen, clear theme. Keeps the launcher, logins and this menu",
                R.drawable.ic_home_settings, v -> resetDebloat());
        // Always visible (both menu states): Reapply and Reset need the executor, and it dies
        // when the TV is powered off - the owner can bring it back without a PC.
        addRow("Start daemon (Reapply/Reset service)", daemonStateDesc(),
                R.drawable.ic_home_settings, v -> startDaemon());
        // Live status line: refresh the description whenever the owner focuses the row.
        daemonRowDesc = lastRowDesc;
        lastRow.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus && daemonRowDesc != null) daemonRowDesc.setText(daemonStateDesc());
        });
        if (buildActive) {
addRow("Self-Test (check build)", "Verify debloat, theme, tweaks and shortcuts are still applied - also runs automatically after every Reapply",
                R.drawable.ic_home_settings, v -> runSelfTest(false));
addRow("Reset TV to Factory Defaults", "Erase everything and restore factory settings",
                R.drawable.ic_lock, v -> factoryReset());
        }

        setContentView(root);
        rows.getChildAt(0).requestFocus();

        // Arrived from a finished "Reapply Debloat and Tweaks": show the self-test report.
        if (getIntent() != null && getIntent().getBooleanExtra("auto_self_test", false)) runSelfTest(true);
    }

    private void addRow(String title, String desc, int icon, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(24), dp(18), dp(24), dp(18));
        row.setBackground(getDrawable(R.drawable.settings_choice_bg));
        row.setFocusable(true);
        row.setFocusableInTouchMode(true);

        TextView ic = new TextView(this);
        ic.setText("\u25A0");
        ic.setTextColor(0xFF8AB4F8);
        ic.setTextSize(20);
        ic.setPadding(0, 0, dp(20), 0);
        row.addView(ic);

        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(20);
        TextView d = new TextView(this);
        d.setText(desc);
        d.setTextColor(0xFF9AA0A6);
        d.setTextSize(14);
        text.addView(t);
        text.addView(d);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(text, tlp);
        row.setOnClickListener(click);
        rows.addView(row);
        lastRow = row;
        lastRowDesc = d;
    }

    // ---- 1) Add app to home screen -----------------------------------------

    private void addApp() {
        List<String> labels = new ArrayList<>();
        List<String> pkgs = new ArrayList<>();
        PackageManager pm = getPackageManager();
        for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
            Intent launch = pm.getLeanbackLaunchIntentForPackage(ai.packageName);
            if (launch == null) launch = pm.getLaunchIntentForPackage(ai.packageName);
            if (launch == null) continue;
            String label = ai.loadLabel(pm).toString();
            labels.add(label);
            pkgs.add(ai.packageName);
        }
        final String[] L = labels.toArray(new String[0]);
        final String[] P = pkgs.toArray(new String[0]);
        java.util.Arrays.sort(L);
        ListView list = new ListView(this);
        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_activated_1, L));
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // find the package matching the (sorted) label
                String chosen = L[position];
                String pkg = null;
                for (int i = 0; i < L.length; i++) if (L[i].equals(chosen)) { pkg = matchPkg(P, chosen); break; }
                if (pkg == null) pkg = P[position];
                addToDock(pkg);
            }
        });
        new AlertDialog.Builder(this)
                .setTitle("Add app to home screen")
                .setMessage("Choose an app to pin to the dock:")
                .setView(list)
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String matchPkg(String[] pkgs, String label) {
        PackageManager pm = getPackageManager();
        for (String p : pkgs) {
            try { if (pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString().equals(label)) return p; }
            catch (Exception ignored) { }
        }
        return null;
    }

    private void addToDock(String pkg) {
        try {
            List<String> dock = readDock();
            if (dock.contains(pkg)) {
                toast("Already on the home screen");
                return;
            }
            dock.add(pkg);
            writeDock(dock);
            toast("Added to home screen");
            restartHome();
        } catch (Exception e) {
            toast("Could not add: " + e.getMessage());
        }
    }

    /** Unpin a dock app. The dock row shrinks back to 4 slots once it drops to 4 or fewer apps (see MainActivity). */
    private void removeApp() {
        try {
            List<String> dock = readDock();
            if (dock.isEmpty()) { toast("The dock is empty"); return; }
            PackageManager pm = getPackageManager();
            List<String> labels = new ArrayList<>();
            for (String p : dock) {
                try { labels.add(pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString()); }
                catch (Exception e) { labels.add(p); }
            }
            final String[] L = labels.toArray(new String[0]);
            final List<String> D = dock;
            ListView list = new ListView(this);
            list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_activated_1, L));
            list.setOnItemClickListener((parent, view, position, id) -> {
                D.remove(position);
                try { writeDock(D); toast("Removed from home screen"); restartHome(); }
                catch (Exception e) { toast("Could not remove: " + e.getMessage()); }
            });
            new AlertDialog.Builder(this)
                    .setTitle("Remove app from home screen")
                    .setMessage("Choose a dock app to unpin:")
                    .setView(list)
                    .setNegativeButton("Cancel", null)
                    .show();
        } catch (Exception e) { toast("Could not list dock apps: " + e.getMessage()); }
    }

    // ---- 2) Rearrange dock apps --------------------------------------------

    private void rearrange() {
        final List<String> dock = readDock();
        if (dock.isEmpty()) { toast("The dock is empty"); return; }
        pendingRearrange = -1;
        ListView list = new ListView(this);
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_activated_1, new ArrayList<>(dock));
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            if (pendingRearrange < 0) {
                pendingRearrange = position;                 // pick up
                adapter.notifyDataSetChanged();
                toast("Now move to the new position and press OK");
            } else {
                String item = dock.remove(pendingRearrange); // drop
                int at = position > pendingRearrange ? position - 1 : position;
                dock.add(Math.max(0, Math.min(dock.size(), at)), item);
                pendingRearrange = -1;
                adapter.clear();
                adapter.addAll(dock);
                try { writeDock(dock); toast("Order saved"); }
                catch (Exception e) { toast("Could not save: " + e.getMessage()); }
            }
        });
        new AlertDialog.Builder(this)
                .setTitle("Rearrange home screen apps")
                .setMessage("Press OK to pick an app up, move, press OK to place it.")
                .setView(list)
                .setNeutralButton("Done", (d, w) -> restartHome())
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---- Themes -------------------------------------------------------------

    /** Display name + asset folder, in menu order. */
    private static final String[][] THEMES = {
            {"Apple TV (Default)", "apple-default"},
            {"Better Glass", "better-glass"},
            {"Aurora", "aurora"},
            {"Glass", "glass"},
            {"Ruska", "ruska"},
            {"Scenes", "scenes"},
            {"Six Columns", "six-columns"},
            {"Sweden", "sweden"},
    };

    private void pickTheme() {
        String[] names = new String[THEMES.length];
        for (int i = 0; i < THEMES.length; i++) names[i] = THEMES[i][0];
        // A ListView in the custom panel (the same pattern as Add/Remove/Rearrange): on this TCL
        // firmware the framework's setItems list does not render for a long list, so the picker is
        // scrollable and always visible.
        ListView list = new ListView(this);
        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_activated_1, names));
        list.setOnItemClickListener((parent, view, position, id) -> applyTheme(THEMES[position][1]));
        new AlertDialog.Builder(this)
                .setTitle("Themes")
                .setMessage("Pick a theme to apply to the home screen:")
                .setView(list)
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Applies a theme the way tools/theme.sh does: writes config.json (keeping the functional base of
     * remote-button shortcuts and the settings key), swaps the wallpaper, stamps a fresh revision so the
     * launcher reloads, then restarts Home and puts the accessibility services back (a force-stop drops them).
     */
    private void applyTheme(final String id) {
        new Thread(() -> {
            try {
                File filesDir = configFile.getParentFile();
                if (filesDir != null && !filesDir.exists()) filesDir.mkdirs();

                JSONObject theme = readAssetJson("themes/" + id + "/config.json");
                if (theme == null) { toastOnUi("Theme not found: " + id); return; }

                // 1) Start from the stock Apple base (a full revert): the functional config
                //    (remote shortcuts, settings key, stats line, cinematic home, Live TV,
                //    colours) plus the standard dock. This clears any leftovers from a
                //    previously applied theme before the new one is layered on.
                JSONObject out = new JSONObject();
                out.put("app_keys", defaultAppKeys());
                out.put("settings_key_panel", true);
                out.put("settings_key_keycodes", new JSONArray().put(83).put(118));
                out.put("show_stats", true);
                out.put("cinematic_home", false);
                out.put("wifi_status_color", true);
                out.put("live_tv_package", "com.tcl.tv");
                out.put("live_tv_input_id", "com.tcl.tvinput/.TunerInputService/HW2");
                out.put("wallpaper_true_color", true);
                out.put("dock_apps", new JSONArray()
                        .put("com.google.android.youtube.tv").put("com.netflix.ninja")
                        .put("com.disney.disneyplus").put("com.amazon.amazonvideo.livingroom"));

                // 2) Layer the theme's own keys on top: its button layout, dock layout,
                //    dock transparency, columns and colours win over the base.
                java.util.Iterator<String> it = theme.keys();
                while (it.hasNext()) {
                    String key = it.next();
                    out.put(key, theme.get(key));
                }
                // The cinematic shelf stretches the focused app's artwork across the whole screen;
                // with YouTube focused that reads as a harsh red-and-white band over the theme's
                // wallpaper. The reference themes keep it off (a soft centred ambient glow instead),
                // so force it off for the stock themes. Better Glass is the owner's custom cinematic
                // theme and keeps its own value, untouched.
                if (!"better-glass".equals(id)) out.put("cinematic_home", false);

                try (FileOutputStream fos = new FileOutputStream(configFile)) {
                    fos.write(out.toString(2).getBytes(StandardCharsets.UTF_8));
                }

                // 3) Wallpaper: the theme's single image, or its rotating collection; a theme
                //    with neither (Apple base, Better Glass, Six Columns) uses a plain background.
                File wp = new File(filesDir, "wallpaper.jpg");
                File wpDir = new File(filesDir, "wallpapers");
                if (!wpDir.exists()) wpDir.mkdirs();
                boolean hasSingle = assetExists("themes/" + id + "/wallpaper.jpg");
                String[] rot;
                try { rot = getAssets().list("themes/" + id + "/wallpapers"); }
                catch (Exception e) { rot = null; }
                if (hasSingle) {
                    copyAsset("themes/" + id + "/wallpaper.jpg", wp);
                    clearDir(wpDir);
                } else if (rot != null && rot.length > 0) {
                    wp.delete();
                    clearDir(wpDir);
                    for (String name : rot) copyAsset("themes/" + id + "/wallpapers/" + name, new File(wpDir, name));
                } else {
                    wp.delete();
                    clearDir(wpDir);
                }

                // 4) Bump the revision and restart Home so the new config + wallpaper load.
                try (FileOutputStream fos = new FileOutputStream(new File(filesDir, "theme_revision"))) {
                    fos.write(UUID.randomUUID().toString().getBytes(StandardCharsets.US_ASCII));
                } catch (Exception ignored) { }
                toastOnUi("Applying themeÃ¢â‚¬Â¦");
                restartHomeReliably();
            } catch (Exception e) {
                toastOnUi("Theme failed: " + e.getMessage());
            }
        }).start();
    }

    private Object defaultAppKeys() {
        JSONArray a = new JSONArray();
        a.put("4062:com.netflix.ninja");
        a.put("4159:com.tcl.browser");
        a.put("4099:com.amazon.amazonvideo.livingroom");
        a.put("190:com.google.android.youtube.tv");
        return a;
    }

    private JSONObject readAssetJson(String path) {
        try (java.io.InputStream in = getAssets().open(path)) {
            byte[] buf = new byte[65536];
            int n = 0, r;
            while (n < buf.length && (r = in.read(buf, n, buf.length - n)) > 0) n += r;
            return new JSONObject(new String(buf, 0, n, StandardCharsets.UTF_8));
        } catch (Exception e) {
            return null;
        }
    }

    private boolean assetExists(String path) {
        try (java.io.InputStream in = getAssets().open(path)) {
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void copyAsset(String path, File dest) throws Exception {
        try (java.io.InputStream in = getAssets().open(path);
             FileOutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[65536];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
        }
    }

    private JSONObject readJsonFile(File file) {
        if (!file.isFile() || file.length() > 64 * 1024) return null;
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] buf = new byte[(int) file.length()];
            int n = 0, r;
            while (n < buf.length && (r = in.read(buf, n, buf.length - n)) > 0) n += r;
            String text = new String(buf, 0, n, StandardCharsets.UTF_8);
            if (text.startsWith("\uFEFF")) text = text.substring(1);
            return new JSONObject(text);
        } catch (Exception e) {
            return null;
        }
    }

    private void toastOnUi(final String s) {
        runOnUiThread(() -> toast(s));
    }

    // ---- 3) Reapply Debloat and Tweaks -------------------------------------

    /**
     * The build package: the debloat list (built-in, or debloat.txt from a USB folder) plus the
     * theme/tweaks (built-in assets, or config.json + wallpaper.jpg from the USB folder), plus an
     * optional newer launcher (app-release.apk from the USB folder). Everything is reversible.
     */
    private void reapplyDebloat() {
        new AlertDialog.Builder(this)
                .setTitle("Reapply Debloat and Tweaks")
                .setItems(new String[]{"On TV (built-in)", "From a folder on a USB stick"},
                        (d, w) -> { if (w == 0) applyBuiltIn(); else pickUsbFolder(); })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Built-in build package: the DEBLOAT list + the embedded config/wallpaper (assets/build-package/). */
    private void applyBuiltIn() {
        byte[] config = readAssetBytes("build-package/config.json");
        byte[] wallpaper = readAssetBytes("build-package/wallpaper.jpg");
        applyBuild(DEBLOAT, config, wallpaper, null, null);
    }

    private void pickUsbFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        try { startActivityForResult(i, REQ_USB); }
        catch (ActivityNotFoundException e) { toast("No file picker available"); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_USB || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri tree = data.getData();
        try { getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) { }
        // Map child file name -> document URI (framework DocumentsContract, no extra dependency).
        java.util.Map<String, Uri> files = new java.util.HashMap<>();
        try {
            String rootId = DocumentsContract.getTreeDocumentId(tree);
            Uri rootDoc = DocumentsContract.buildDocumentUriUsingTree(tree, rootId);
            Cursor c = getContentResolver().query(rootDoc, null, null, null, null);
            if (c != null) {
                int iId = c.getColumnIndex("_id");
                int iName = c.getColumnIndex("display_name");
                while (c.moveToNext()) {
                    if (iId < 0 || iName < 0) continue;
                    String id = c.getString(iId);
                    String name = c.getString(iName);
                    if (id != null && name != null)
                        files.put(name, DocumentsContract.buildDocumentUriUsingTree(tree, id));
                }
                c.close();
            }
        } catch (Exception e) { toast("Could not read folder: " + e.getMessage()); return; }
        List<String> pkgs = new ArrayList<>();
        Uri debloat = files.get("debloat.txt");
        if (debloat != null) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(
                    getContentResolver().openInputStream(debloat), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty() || line.startsWith("#")) continue;
                    pkgs.add(line);
                }
            } catch (Exception e) { toast("Could not read debloat.txt: " + e.getMessage()); return; }
        }
        if (pkgs.isEmpty()) { toast("Put debloat.txt in the build package folder"); return; }
        byte[] config = null;
        Uri cfg = files.get("config.json");
        if (cfg != null) config = readUriBytes(cfg);
        byte[] wallpaper = null;
        Uri wp = files.get("wallpaper.jpg");
        if (wp != null) wallpaper = readUriBytes(wp);
        File apk = null;
        Uri apkUri = files.get("app-release.apk");
        if (apkUri != null) apk = copyUriToFiles(apkUri, "app-release.apk");
        // The selected tree's removable-volume UUID (authoritative metadata only) binds the
        // completion report to THIS stick so an unrelated volume removal never closes it.
        applyBuild(pkgs.toArray(new String[0]), config, wallpaper, apk, usbVolumeFromTree(tree));
    }

    private byte[] readUriBytes(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            return readAll(in);
        } catch (Exception e) { return null; }
    }

    private File copyUriToFiles(Uri uri, String name) {
        try {
            File dir = configFile.getParentFile();
            if (dir != null && !dir.exists()) dir.mkdirs();
            File out = new File(dir, name);
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream fos = new FileOutputStream(out)) {
                byte[] buf = new byte[8192]; int r;
                while ((r = in.read(buf)) > 0) fos.write(buf, 0, r);
            }
            return out;
        } catch (Exception e) { return null; }
    }

    private byte[] readAssetBytes(String path) {
        try (InputStream in = getAssets().open(path)) {
            return readAll(in);
        } catch (Exception e) { return null; }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int r;
        while ((r = in.read(buf)) > 0) bos.write(buf, 0, r);
        return bos.toByteArray();
    }

    private void applyBuild(final String[] pkgs, final byte[] config, final byte[] wallpaper, final File apk, final String usbVol) {
        // Trusted input: every entry must at least be a well-formed package name, and anything
        // outside the vetted 33-entry allowlist is shown explicitly in the confirmation below.
        List<String> entries = KitPolicy.entries(pkgs);
        if (!KitPolicy.isAllWellFormed(entries)) {
            toastOnUi("Package list contains an invalid package name - nothing was applied");
            return;
        }
        String extra = "";
        List<String> nonVet = KitPolicy.nonVetted(entries);
        if (!nonVet.isEmpty()) extra = "Non-standard entries: " + String.join(", ", nonVet) + "\n";
        new AlertDialog.Builder(this)
                .setTitle("Reapply Debloat and Tweaks")
                .setMessage(extra + "Re-disable " + pkgs.length + " packages and reapply the theme, tweaks and "
                        + "Live TV settings? This is reversible." + daemonWarning())
                .setPositiveButton("Apply", (d, w) -> new Thread(() -> {
                    File filesDir = configFile.getParentFile();
                    if (filesDir != null && !filesDir.exists()) filesDir.mkdirs();
                    // Best effort: make sure the executor is up (it dies when the TV powers off).
                    if (!ensureExecutorRunning()) { toastOnUi("No full-rights daemon. Start the service before applying changes."); return; }
                    // Package state changes run in the shell-level executor (the app's own uid cannot
                    // change component state - it is signature-level). Hand it the list first.
                    writePkgList(pkgs);
                    boolean isUsb = usbVol != null;
                    long startSec = System.currentTimeMillis() / 1000L;
                    if (isUsb) writeUsbTxn("manual", usbVol, "pending", -1, -1, "-", startSec, false);
                    boolean cfgDone = false, wpDone = false;
                    if (config != null) {
                        try (FileOutputStream fos = new FileOutputStream(configFile)) {
                            fos.write(config); cfgDone = true;
                        } catch (Exception ignored) { }
                    }
                    if (wallpaper != null) {
                        try (FileOutputStream fos = new FileOutputStream(new File(filesDir, "wallpaper.jpg"))) {
                            fos.write(wallpaper); wpDone = true;
                        } catch (Exception ignored) { }
                    }
                    try (FileOutputStream fos = new FileOutputStream(new File(filesDir, "theme_revision"))) {
                        fos.write(UUID.randomUUID().toString().getBytes(StandardCharsets.US_ASCII));
                    } catch (Exception ignored) { }
                    boolean apkDone = false;
                    if (isUsb) {
                        // USB: hand the package-state work to the shell executor BEFORE the
                        // self-update - the daemon survives the APK install and finishes the
                        // tail even if this process is killed by the update.
                        if (!sendDaemonCommand("apply")) {
                            // Nothing will run: record the failure so the report never shows a
                            // stale "pending" as an interruption of work that never started.
                            writeUsbTxn("manual", usbVol, "failed", -1, -1, "no_daemon", System.currentTimeMillis() / 1000L, false);
                            toastOnUi("No full-rights daemon. Start the service before applying changes.");
                            return;
                        }
                    }
                    if (apk != null && apk.isFile()) {
                        apkDone = runShell("pm", "install", "-r", apk.getAbsolutePath()) == 0;
                    }
                    // Shell executor: re-disable the packages + switch Home back to this launcher.
                    String res = isUsb ? waitForDaemonResult(startSec, 30000, "apply") : requestDaemon("apply");
                    final boolean cF = cfgDone, wF = wpDone, aF = apkDone;
                    final String rF = res;
                    if (isUsb) {
                        // Commit the durable completion only when the executor confirmed it. A
                        // missing result stays "pending"; the report resolves it from evidence.
                        if (res != null && res.contains("ok=")) {
                            int ok = -1, fail = -1;
                            for (String tok : res.split("\\s+")) {
                                if (tok.startsWith("ok=")) { try { ok = Integer.parseInt(tok.substring(3)); } catch (Exception ignored) {} }
                                if (tok.startsWith("fail=")) { try { fail = Integer.parseInt(tok.substring(3)); } catch (Exception ignored) {} }
                            }
                            writeUsbTxn("manual", usbVol, "completed", ok, fail, "-", System.currentTimeMillis() / 1000L, false);
                        } else if (res != null && res.contains("rejected=1")) {
                            writeUsbTxn("manual", usbVol, "failed", -1, -1, "rejected_list", System.currentTimeMillis() / 1000L, false);
                        }
                    } else {
                        // Flag for the fresh process (the restart below kills this one): show the self-test.
                        try { new File(filesDir, "selftest_pending").createNewFile(); } catch (Exception ignored) { }
                    }
                    // Mark the build as active so the TV Setup menu shows the full customization list.
                    try { new File(filesDir, "build_applied").createNewFile(); } catch (Exception ignored) { }
                    runOnUiThread(() -> toast("Build applied: " + parseDaemonResult(rF)
                            + (cF ? " + theme/tweaks" : "")
                            + (aF ? " + launcher updated" : "")));
                    restartHomeReliably();
                }).start())
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Deletes the contents of a directory (the theme wallpaper rotation folder). */
    private void clearDir(File dir) {
        if (dir == null || !dir.exists()) return;
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) if (f != null) f.delete();
    }

    /**
     * Restart Home so a freshly written config + wallpaper load. A detached watchdog relaunches
     * the launcher if the system hasn't already, then this process is killed (force-stop from the
     * app's own uid does not reliably restart the launcher on this firmware).
     */
    private void restartHomeReliably() {
        try {
            new ProcessBuilder("sh", "-c",
                    "sleep 3; am start -n " + getPackageName() + "/.MainActivity >/dev/null 2>&1").start();
        } catch (Exception ignored) { }
        android.os.Process.killProcess(android.os.Process.myPid());
    }

    /**
     * Reset Debloat settings (not a factory reset): re-enables every debloated package and the
     * stock launcher, restores the stock Home screen and clears the launcher's theme and config
     * files. Keeps: the launcher APK with its built-in build package, all app data and logins,
     * and the TV Setup menu (remote settings key) with its Reapply + Reset buttons.
     */
    private void resetDebloat() {
        new AlertDialog.Builder(this)
                .setTitle("Reset Debloat settings")
                .setMessage("Re-enable the debloated packages and restore the stock home screen. "
                        + "Keeps your app logins, in-app customisations, the launcher (with its "
                        + "built-in build) and the TV Setup menu on the remote settings key. Not a "
                        + "factory reset." + daemonWarning())
                .setPositiveButton("Reset", (d, w) -> new Thread(() -> {
                    File filesDir = configFile.getParentFile();
                    // Best effort: make sure the executor is up (it dies when the TV powers off).
                    if (!ensureExecutorRunning()) { toastOnUi("No full-rights daemon. Start the service before applying changes."); return; }
                    // App-level: drop the "build active" marker so the TV Setup menu collapses to just
                    // Reapply + Reset. Keep config.json (the user's dock/tile customisations) and all
                    // app data/logins - this is not a factory reset.
                    boolean markersCleared = true;
                    if (filesDir != null) {
                        for (String n : new String[]{"build_applied", "selftest_pending", "usb_applied"}) {
                            File f = new File(filesDir, n);
                            if (f.isFile() && !f.delete()) markersCleared = false;
                        }
                    }
                    // Shell executor: re-enable every debloated package + the stock launcher and switch
                    // Home back to the stock launcher (the app's own uid cannot do this).
                    String res = requestDaemon("reset");
                    final String rF = res;
                    final boolean mF = markersCleared;
                    runOnUiThread(() -> toast("Debloat reset: " + parseDaemonResult(rF)
                            + (mF ? ", menu cleared" : "")
                            + (rF == null ? " - debloat service offline" : "")));
                    // Leave this launcher behind: the stock home takes over, and TV Setup stays on
                    // the remote settings key (firmware CustomKey mapping, survives the reset).
                    // 2026-10-29 fix (home handoff): the old explicit-component am start fired 2 s
                    // after pm enable and could fail silently (async PMS->AM propagation), and the
                    // self-kill below did not re-resolve the preferred home, so the screen stayed on
                    // this launcher until the user pressed Home. Dispatch HOME now (the daemon step
                    // above already set the preferred home to stock) and keep a HOME-dispatch
                    // fallback in case this dispatch is swallowed by the self-kill.
                    try {
                        startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception ignored) { }
                    try {
                        new ProcessBuilder("sh", "-c",
                                "sleep 2; am start -a android.intent.action.MAIN -c android.intent.category.HOME >/dev/null 2>&1").start();
                    } catch (Exception ignored) { }
                    android.os.Process.killProcess(android.os.Process.myPid());
                }).start())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private int runShell(String... cmd) {
        try {
            Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) {
                    if (out.length() < 500) out.append(line).append('\n');
                }
            }
            int rc = p.waitFor();
            try {
                File log = new File(getExternalFilesDir(null), "shell.log");
                java.io.FileWriter w = new java.io.FileWriter(log, true);
                w.write(String.join(" ", cmd) + " -> rc=" + rc + " out=" + out + "\n");
                w.close();
            } catch (Exception ignored) { }
            return rc;
        } catch (Exception e) { return -1; }
    }

    /** Run a command and return its combined output (for existence checks). */
    private String runShellOut(String... cmd) {
        try {
            Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) out.append(line).append('\n');
            }
            p.waitFor();
            return out.toString();
        } catch (Exception e) { return ""; }
    }

    /** True if the package is installed (exact "package:<name>" line in the list). */
    private static boolean isInstalled(String list, String pkg) {
        for (String line : list.split("\n")) {
            if (line.trim().equals("package:" + pkg)) return true;
        }
        return false;
    }

    // ---- Shell-level executor (cys-daemon) ---------------------------------
    // The app's own uid (10108) cannot change package component state: the
    // CHANGE_COMPONENT_ENABLED_STATE permission is signature-level, so `pm
    // enable/disable-user` run from the app fail (rc=255). A small shell script
    // (cys-daemon, uid 2000) runs those commands instead. The app talks to it
    // through files in its external files dir (both can read and write there).

    /** Write the package list the executor should disable for an "apply". */
    private void writePkgList(String[] pkgs) {
        try {
            File f = new File(getExternalFilesDir(null), "pkg-list.txt");
            StringBuilder sb = new StringBuilder();
            for (String p : pkgs) if (p != null && !p.isEmpty()) sb.append(p).append('\n');
            try (FileOutputStream fos = new FileOutputStream(f)) {
                fos.write(sb.toString().getBytes(StandardCharsets.US_ASCII));
            }
        } catch (Exception ignored) { }
    }

    /** True if the executor answered within the last 10 s (heartbeat file). */
    private boolean daemonAlive() {
        try {
            File ping = new File(getExternalFilesDir(null), "daemon-ping.txt");
            if (!ping.isFile()) return false;
            long ts = Long.parseLong(readSmall(ping));
            long age = System.currentTimeMillis() / 1000L - ts;
            return age >= 0 && age <= 3;
        } catch (Exception e) { return false; }
    }

    /** The uid the executor self-reported (2000 = shell/full rights), or -1 if unknown. */
    private int daemonUid() {
        try {
            return Integer.parseInt(readSmall(new File(getExternalFilesDir(null), "daemon-uid.txt")));
        } catch (Exception e) { return -1; }
    }

    /** "full" (shell executor alive), "limited" (app-uid executor alive) or "none". */
    private String daemonState() {
        if (!daemonAlive()) return "none";
        return daemonUid() == 2000 ? "full" : "limited";
    }

    /** Live status line for the "Start daemon" menu row. */
    private String daemonStateDesc() {
        String s = daemonState();
        if (s.equals("full")) return "Running (full rights) - Reapply and Reset ready";
        if (s.equals("limited")) return "Limited service detected - tap to replace it with the full-rights service";
        return "Not running - tap to start with full rights; approve TV debugging if requested";
    }

    /** Restores/refreshes the executor script from the embedded copy (see the static variant). */
    private boolean ensureDaemonScript() {
        return ensureDaemonScriptStatic(this);
    }

    /** Authenticated local ADB starts the daemon as shell UID 2000; no app-UID fallback. */
    private boolean launchDaemonProcess() {
        synchronized (DAEMON_START_LOCK) {
            // Always verify the packaged revision through authenticated ADB.
            try {
                if (!ensureDaemonScript()) throw new java.io.IOException("Daemon script unavailable");
                android.util.Log.i("CysAdb", "owner start caller_uid=" + android.os.Process.myUid()
                        + " endpoint=127.0.0.1:5555");
                toastOnUi("Starting full service. Approve the TV debugging request if shown, then retry if needed.");
                java.security.KeyPair pair = AdbIdentity.loadOrCreate(getFilesDir());
                AdbShellClient client = new AdbShellClient(pair.getPrivate(), null, null, true);
                client.startFullDaemon("127.0.0.1", 5555, this::killAppDaemons, daemonScriptHash());
                if (!daemonAlive() || daemonUid() != 2000)
                    throw new java.io.IOException("No fresh shell-UID daemon confirmation");
                android.util.Log.i("CysAdb", "full daemon confirmed caller_uid=" + android.os.Process.myUid());
                return true;
            } catch (Exception e) {
                android.util.Log.e("CysAdb", "Full daemon start failed: " + e.getClass().getSimpleName()
                        + ": " + e.getMessage());
                toastOnUi("Full service did not start: " + e.getMessage()
                        + ". Approve TV debugging if requested, then tap Start daemon again.");
                return false;
            }
        }
    }

    /**
     * USB kit auto-setup (the "put it on a USB stick" build). Starts the shell executor and asks
     * it to find the kit on a removable volume and apply it; the daemon then exits on its own, so
     * the service is shut down right after the debloat is re-applied. Runs off the UI thread and
     * is safe to call from MainActivity on a fresh home launch. Returns the executor's result line
     * ("usb ts=... ok=N fail=M home=tvhome" or "usb ts=... none=1"), or null if the executor could
     * not be started or did not answer in time.
     */
    public static String runUsbApply(Context ctx) {
        try {
            File files = ctx.getExternalFilesDir(null);
            if (files == null) return null;
            // The daemon derives the mounted removable volume roots itself (authoritative
            // 'sm list-volumes public') and validates the kit package list against its own
            // embedded vetted allowlist - so the command is a bare "usb" with no arguments.
            if (!launchDaemonStatic(ctx)) return null;
            long start = System.currentTimeMillis() / 1000L;
            File cmdF = new File(files, "pkg-cmd.txt");
            if (cmdF.exists()) cmdF.delete();
            try (FileOutputStream fos = new FileOutputStream(cmdF)) {
                fos.write("usb".getBytes(StandardCharsets.US_ASCII));
            }
            File resF = new File(files, "pkg-result.txt");
            long deadline = System.currentTimeMillis() + 30000; // allow time for pm install + disables
            while (System.currentTimeMillis() < deadline) {
                if (resF.isFile()) {
                    String r = readSmall(resF);
                    long ts = parseTs(r);
                    if (r.startsWith("usb") && (ts < 0 || ts >= start)) return r;
                }
                try { Thread.sleep(400); } catch (InterruptedException ie) { break; }
            }
            return null;
        } catch (Exception e) {
            android.util.Log.e("CysAdb", "USB apply failed: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            return null;
        }
    }

    /** Static daemon liveness check (heartbeat file), used by the USB auto-apply path. */
    private static boolean daemonAliveStatic(Context ctx) {
        try {
            File ping = new File(ctx.getExternalFilesDir(null), "daemon-ping.txt");
            if (!ping.isFile()) return false;
            long ts = Long.parseLong(readSmall(ping));
            long age = System.currentTimeMillis() / 1000L - ts;
            return age >= 0 && age <= 3;
        } catch (Exception e) { return false; }
    }

    /** Static daemon uid check (2000 = shell/full rights), used by the USB auto-apply path. */
    private static int daemonUidStatic(Context ctx) {
        try {
            return Integer.parseInt(readSmall(new File(ctx.getExternalFilesDir(null), "daemon-uid.txt")));
        } catch (Exception e) { return -1; }
    }

    /**
     * Restore the executor script from the embedded copy. Self-healing: if the on-disk script
     * differs from the embedded one (an older build left its copy in /data/local/tmp), replace it,
     * so the build that is running always has the daemon commands it expects. Only reached when
     * no live daemon is answering (both callers check liveness first), so a running script is not
     * rewritten under its own feet.
     */
    private static String daemonScriptHash() {
        try {
            byte[] digest = java.security.MessageDigest.getInstance("SHA-256")
                    .digest(DAEMON_SCRIPT.getBytes(StandardCharsets.US_ASCII));
            StringBuilder hex = new StringBuilder();
            for (byte b : digest) hex.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
            return hex.toString();
        } catch (java.security.NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
    }

    private static boolean ensureDaemonScriptStatic(Context ctx) {
        try {
            File ext = ctx.getExternalFilesDir(null);
            if (ext == null) return false;
            File f = new File(ext, "daemon-script.sh");
            String expected = DAEMON_SCRIPT;
            if (f.isFile() && f.length() > 100) {
                byte[] onDisk = java.nio.file.Files.readAllBytes(f.toPath());
                if (new String(onDisk, StandardCharsets.US_ASCII).equals(expected)) return true;
            }
            if (!ext.exists()) ext.mkdirs();
            try (FileOutputStream fos = new FileOutputStream(f)) {
                fos.write(expected.getBytes(StandardCharsets.US_ASCII));
            }
            return true;
        } catch (Exception e) { return false; }
    }

    /**
     * Start the full-rights (shell uid 2000) executor from the app's own authenticated local ADB
     * identity - the same path the "Start daemon" button uses. Static so the USB auto-apply can run
     * without a TVSetupActivity instance.
     */
    private static boolean launchDaemonStatic(Context ctx) {
        synchronized (DAEMON_START_LOCK) {
            // Always refresh through authenticated ADB: an installed update may carry a new script.
            try {
                if (!ensureDaemonScriptStatic(ctx)) throw new java.io.IOException("Daemon script unavailable");
                android.util.Log.i("CysAdb", "usb apply start caller_uid=" + android.os.Process.myUid() + " endpoint=127.0.0.1:5555");
                java.security.KeyPair pair = AdbIdentity.loadOrCreate(ctx.getFilesDir());
                AdbShellClient client = new AdbShellClient(pair.getPrivate(), null, null, true);
                client.startFullDaemon("127.0.0.1", 5555, () -> {}, daemonScriptHash());
                if (!daemonAliveStatic(ctx) || daemonUidStatic(ctx) != 2000)
                    throw new java.io.IOException("No fresh shell-UID daemon confirmation");
                android.util.Log.i("CysAdb", "usb apply daemon confirmed caller_uid=" + android.os.Process.myUid());
                return true;
            } catch (Exception e) {
                android.util.Log.e("CysAdb", "USB apply daemon start failed: " + e.getClass().getSimpleName() + ": " + e.getMessage());
                return false;
            }
        }
    }

    /**
     * Kill any executor processes this app owns (its own uid) so a stale app-uid daemon does not
     * race a fresh one. Shell-uid (ADB-started) executors are left alone - cross-uid kills fail.
     */
    private void killAppDaemons() {
        try {
            File[] pids = new File("/proc").listFiles((d, n) -> n.matches("\\d+"));
            if (pids == null) return;
            for (File pidDir : pids) {
                try {
                    File cmd = new File(pidDir, "cmdline");
                    if (!cmd.isFile()) continue;
                    byte[] b = new byte[256];
                    int n; StringBuilder sb = new StringBuilder();
                    try (java.io.FileInputStream fis = new java.io.FileInputStream(cmd)) {
                        while ((n = fis.read(b)) > 0) sb.append(new String(b, 0, n, StandardCharsets.US_ASCII));
                    }
                    String cl = sb.toString().replace("\u0000", " ").trim();
                    if (cl.equals("sh " + DAEMON_PATH) || cl.equals("/system/bin/sh " + DAEMON_PATH)
                            || cl.equals("sh " + DAEMON_PATH_NEW) || cl.equals("/system/bin/sh " + DAEMON_PATH_NEW)) {
                        try { android.os.Process.killProcess(Integer.parseInt(pidDir.getName())); }
                        catch (Exception ignored) { }
                    }
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
    }

    /** Wait up to the timeout for the executor's heartbeat. */
    private boolean waitForDaemon(long timeoutMs) {
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (!daemonAlive() && System.currentTimeMillis() < deadline) {
            try { Thread.sleep(400); } catch (InterruptedException ie) { break; }
        }
        return daemonAlive();
    }

    /** Restore the script if needed and launch the executor if it is not answering. */
    private boolean ensureExecutorRunning() {
        return launchDaemonProcess();
    }

    /**
     * "Start daemon" menu action: restore the script if needed, launch the executor if it is
     * not answering, wait for its heartbeat and report the result. Background thread.
     */
    private void startDaemon() {
        if (!DAEMON_BUTTON_BUSY.compareAndSet(false, true)) {
            toast("Service start already in progress"); return;
        }
        new Thread(() -> {
            try {
                if (launchDaemonProcess()) toastOnUi("Daemon running (full) - Reapply and Reset ready");
            } finally {
                DAEMON_BUTTON_BUSY.set(false);
                runOnUiThread(() -> { if (daemonRowDesc != null) daemonRowDesc.setText(daemonStateDesc()); });
            }
        }, "CysAdbStart").start();
    }

    /** Warning line for the Reapply/Reset dialogs when the executor cannot do its job. */
    private String daemonWarning() {
        if (daemonState().equals("full")) return "";
        return "\n\nThe full-rights service must start before package changes. Approve the TV debugging request if shown. Changes stop if the service cannot start.";
    }

    /** Read a small text file (daemon result / heartbeat). */
    private static String readSmall(File f) {
        String text = UsbTransaction.readRecord(f, 16384);
        return text == null ? "" : text.trim();
    }

    /**
     * Ask the shell-level executor to run a package-state command ("apply" or "reset") and wait for
     * its result. Returns the executor's result line, or null if it did not answer in time (e.g. the
     * TV rebooted and the executor was not restarted). The app-level work (theme/config) is separate
     * and always runs; only the package-state + Home switch depend on the executor.
     */
    private String requestDaemon(String cmd) {
        File files = getExternalFilesDir(null);
        if (files == null || !daemonAlive()) return null; // fail fast if the executor is offline
        long start = System.currentTimeMillis() / 1000L;
        if (!sendDaemonCommand(cmd)) return null;
        return waitForDaemonResult(start, 12000, cmd);
    }

    /** Write the executor command file (the daemon picks it up within its 1 s loop). */
    private boolean sendDaemonCommand(String cmd) {
        File files = getExternalFilesDir(null);
        if (files == null || !daemonAlive()) return false;
        try {
            File cmdF = new File(files, "pkg-cmd.txt");
            if (cmdF.exists()) cmdF.delete();
            try (FileOutputStream fos = new FileOutputStream(cmdF)) {
                fos.write(cmd.getBytes(StandardCharsets.US_ASCII));
            }
        } catch (Exception e) { return false; }
        return true;
    }

    /** Wait up to the timeout for a fresh executor result (ts >= start). When prefix is set, only
     *  a result line from THAT command counts - a concurrent "usb" auto-apply result (or any other
     *  command's) is never mistaken for this request's answer. */
    private String waitForDaemonResult(long start, long timeoutMs, String prefix) {
        File resF = new File(getExternalFilesDir(null), "pkg-result.txt");
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            if (resF.isFile()) {
                String r = readSmall(resF);
                long ts = parseTs(r);
                if ((ts < 0 || ts >= start) && (prefix == null || r.startsWith(prefix))) return r; // fresh result
            }
            try { Thread.sleep(400); } catch (InterruptedException ie) { break; }
        }
        return null;
    }

    private static long parseTs(String res) {
        for (String tok : res.split("\\s+")) {
            if (tok.startsWith("ts=")) {
                try { return Long.parseLong(tok.substring(3)); } catch (Exception ignored) { return -1; }
            }
        }
        return -1;
    }

    /** Turn an executor result line into a short status string for the toast. */
    private String parseDaemonResult(String res) {
        if (res == null) return "debloat service offline";
        int ok = -1, fail = -1;
        for (String tok : res.split("\\s+")) {
            if (tok.startsWith("ok=")) { try { ok = Integer.parseInt(tok.substring(3)); } catch (Exception ignored) {} }
            if (tok.startsWith("fail=")) { try { fail = Integer.parseInt(tok.substring(3)); } catch (Exception ignored) {} }
        }
        if (ok < 0) return "done";
        return ok + " packages ok" + (fail > 0 ? ", " + fail + " skipped" : "");
    }

    // ---- USB completion transaction + report --------------------------------

    /** Durable USB Reapply record file (flat single line, see UsbTransaction): the shell daemon
     *  commits it for the auto-kit path, this app for the manual USB-folder path. It survives
     *  the APK self-update killing the app process, so the fresh Home can route the report. */
    // (legacy record name is now UsbTransaction.FILE_LEGACY; new records use FILE_TS_PREFIX+ts)

    private UsbTransaction.Txn reportTxn;
    private boolean reportClosed;
    private android.content.BroadcastReceiver reportStorageReceiver;
    private android.os.Handler reportHandler;
    private LinearLayout reportList;
    private TextView reportSum;
    private final Runnable reportPoll = this::onReportStorageEvent;

    /** The newest durable USB transaction record (fresh per-apply name, see UsbTransaction.findLatest). */
    private File findUsbTxnFile() {
        return UsbTransaction.findLatest(getExternalFilesDir(null));
    }

    /** Read + strictly validate the newest durable USB transaction; null when absent or malformed. */
    private UsbTransaction.Txn readUsbTxn() {
        try {
            File f = findUsbTxnFile();
            if (f == null) return null;
            // Read a bounded record using the actual byte count returned by each read.
            return UsbTransaction.decode(UsbTransaction.readRecord(f, 1024));
        } catch (Exception e) { return null; }
    }

    /** Sweep stale transaction records (>24 h) so the per-apply fresh names never accumulate. */
    private void sweepOldUsbTxn() {
        try {
            File dir = getExternalFilesDir(null);
            if (dir == null) return;
            File[] all = dir.listFiles((d, name) ->
                    UsbTransaction.isRecordName(name));
            if (all == null) return;
            long cutoff = System.currentTimeMillis() - 86400L * 1000L;
            for (File f : all) if (f != null && f.isFile() && f.lastModified() < cutoff) f.delete();
        } catch (Exception ignored) { }
    }

    private void writeUsbTxn(String src, String vol, String status, int ok, int fail,
                             String reason, long ts, boolean consumed) {
        try {
            File dir = getExternalFilesDir(null);
            if (dir == null) return;
            File f = new File(dir, UsbTransaction.FILE_TS_PREFIX + ts + ".json");
            try (FileOutputStream fos = new FileOutputStream(f)) {
                fos.write(UsbTransaction.encode(src, vol, status, ok, fail, reason, ts, consumed)
                        .getBytes(StandardCharsets.US_ASCII));
            }
        } catch (Exception ignored) { }
    }

    private void markUsbTxnConsumed() {
        UsbTransaction.consumeRecord(findUsbTxnFile());
    }

    /** True when the transaction's kit volume is still a mounted removable volume (authoritative
     *  StorageManager metadata - an unrelated stick never matches the recorded UUID). */
    private boolean kitVolumeMounted(String uuid) {
        try {
            if (android.os.Build.VERSION.SDK_INT < 29) return false;
            android.os.storage.StorageManager sm =
                    (android.os.storage.StorageManager) getSystemService(Context.STORAGE_SERVICE);
            if (sm == null) return false;
            for (android.os.storage.StorageVolume v : sm.getStorageVolumes())
                if (v.isRemovable() && "mounted".equals(v.getState()) && uuid.equals(v.getUuid()))
                    return true;
        } catch (Exception ignored) { }
        return false;    // unknown state: keep the report open, never close on a guess
    }

    /** A fresh shell-executor "apply" result committed inside this transaction's window: the
     *  manual path sends "apply" before the self-update, so the daemon may finish the tail
     *  after the app restarts. Null when absent/stale - the report then never claims success. */
    private String readFreshApplyResult(UsbTransaction.Txn t) {
        try {
            File f = new File(getExternalFilesDir(null), "pkg-result.txt");
            if (!f.isFile()) return null;
            String r = readSmall(f);
            if (r == null || !r.startsWith("apply") || !r.contains("ok=")) return null;
            long ts = parseTs(r);
            long now = System.currentTimeMillis() / 1000L;
            if (ts < t.ts - 10 || ts > now) return null;
            return r;
        } catch (Exception e) { return null; }
    }

    /** The selected tree's removable-volume UUID from its document id (e.g. "ABCD-1234",
     *  "ABCD-1234:" or "primary:ABCD-1234:"), confirmed against the authoritative mounted-volume
     *  metadata - the candidate must equal a currently mounted removable volume's UUID, so an
     *  unrelated or internal tree never binds; null otherwise. */
    private String usbVolumeFromTree(Uri tree) {
        try {
            String id = DocumentsContract.getTreeDocumentId(tree);
            if (id == null) return null;
            String vol = id.endsWith(":") ? id.substring(0, id.length() - 1) : id;
            int c = vol.lastIndexOf(':');
            if (c >= 0) vol = vol.substring(c + 1);
            if (vol.isEmpty() || vol.equals("primary") || !vol.matches("^[A-Za-z0-9_-]{1,32}$")) return null;
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                android.os.storage.StorageManager sm =
                        (android.os.storage.StorageManager) getSystemService(Context.STORAGE_SERVICE);
                if (sm != null)
                    for (android.os.storage.StorageVolume v : sm.getStorageVolumes())
                        if (v.isRemovable() && "mounted".equals(v.getState()) && vol.equals(v.getUuid()))
                            return vol;
            }
        } catch (Exception ignored) { }
        return null;
    }

    /**
     * USB completion report: one surface with a distinct completion card ABOVE the automatic
     * Self-Test results (never over them). It stays open until the SELECTED kit volume is
     * actually ejected/unmounted/removed, then the card and the Self-Test close together.
     * Returns false when there is no valid transaction (the caller shows the normal menu).
     */
    private boolean showUsbReport() {
        reportTxn = readUsbTxn();
        long now = System.currentTimeMillis() / 1000L;
        if (reportTxn == null || reportTxn.consumed || now - reportTxn.ts > 86400) {
            try { File f = findUsbTxnFile(); if (f != null) f.delete(); } catch (Exception ignored) { }
            sweepOldUsbTxn();
            reportTxn = null;
            return false;
        }
        // Still in progress (fresh pending): the operation has not ended, so there is nothing
        // final to report yet. Do not show the report (the card would falsely say "interrupted");
        // MainActivity routes here once it is resolvable and the next open picks it up.
        if (UsbTransaction.resolveStatus(reportTxn, false, now).equals("pending")) return false;
        reportClosed = false;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0B0F14);
        root.setPadding(dp(90), dp(40), dp(90), dp(40));

        TextView title = new TextView(this);
        title.setText("USB Reapply - Report");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(26);
        title.setPadding(0, 0, 0, dp(14));
        root.addView(title);

        // Completion card: a distinct panel above the Self-Test results, never over them.
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(0xFF141B24);
        card.setPadding(dp(16), dp(12), dp(16), dp(12));
        TextView cardStatus = new TextView(this);
        cardStatus.setTextSize(18);
        TextView cardDetail = new TextView(this);
        cardDetail.setTextSize(15);
        cardDetail.setTextColor(0xFFC7D0DA);
        card.addView(cardStatus);
        card.addView(cardDetail);
        root.addView(card, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));

        reportSum = new TextView(this);
        reportSum.setText("Self-Test: running checks...");
        reportSum.setTextSize(18);
        reportSum.setTextColor(0xFF9AA7B4);
        reportSum.setPadding(dp(8), dp(12), dp(8), dp(8));
        root.addView(reportSum);

        reportList = new LinearLayout(this);
        reportList.setOrientation(LinearLayout.VERTICAL);
        reportList.setPadding(dp(8), dp(4), dp(8), dp(4));
        ScrollView sv = new ScrollView(this);
        sv.addView(reportList);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
        fillReportCard(cardStatus, cardDetail, now);

        if (kitVolumeMounted(reportTxn.vol)) {
            startReportWatcher();   // close card + Self-Test when THIS volume is removed
        } else {
            // The kit volume is already gone: show the report with a normal close action.
            addReportCloseRow(root);
        }

        // The automatic Self-Test that belongs to the USB Reapply.
        runSelfTestChecks(results -> runOnUiThread(() -> onReportSelfTestDone(results)));
        return true;
    }

    private void fillReportCard(TextView status, TextView detail, long now) {
        UsbTransaction.Txn t = reportTxn;
        String freshApply = t.status.equals("pending") ? readFreshApplyResult(t) : null;
        String st = UsbTransaction.resolveStatus(t, freshApply != null, now);
        int ok = t.ok, fail = t.fail;
        if (st.equals("completed") && t.status.equals("pending") && freshApply != null) {
            for (String tok : freshApply.split("\\s+")) {
                if (tok.startsWith("ok=")) { try { ok = Integer.parseInt(tok.substring(3)); } catch (Exception ignored) {} }
                if (tok.startsWith("fail=")) { try { fail = Integer.parseInt(tok.substring(3)); } catch (Exception ignored) {} }
            }
        }
        if (st.equals("completed")) {
            status.setTextColor(0xFF3DDC84);
            status.setText("USB Reapply completed");
            detail.setText((ok >= 0
                    ? ok + " packages disabled" + (fail > 0 ? ", " + fail + " skipped" : "") + ", home set, service stopped"
                    : "operation finished")
                    + "\nYou may now use the system Eject to safely remove the stick.");
        } else if (st.equals("failed")) {
            status.setTextColor(0xFFFF5252);
            status.setText("USB Reapply failed");
            detail.setText("Reason: " + t.reason
                    + ". No success markers were set. You may remove the stick and retry with a corrected kit.");
        } else if (st.equals("pending")) {
            status.setTextColor(0xFFFFB74D);
            status.setText("USB Reapply in progress...");
            detail.setText("Waiting for the operation to finish.");
        } else {
            status.setTextColor(0xFFFFB74D);
            status.setText("USB Reapply interrupted during the app update");
            detail.setText("The operation did not finish. Run Reapply again to complete it. You may remove the stick.");
        }
    }

    private void addReportCloseRow(LinearLayout root) {
        TextView b = new TextView(this);
        b.setText("Close report");
        b.setFocusable(true);
        b.setFocusableInTouchMode(true);
        b.setTextSize(18);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundColor(0xFF1E2836);
        b.setPadding(dp(24), dp(10), dp(24), dp(10));
        b.setOnClickListener(v -> { reportClosed = true; markUsbTxnConsumed(); finish(); });
        LinearLayout wrap = new LinearLayout(this);
        wrap.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        wrap.addView(b, new LinearLayout.LayoutParams(-2, -2));
        root.addView(wrap, new LinearLayout.LayoutParams(-1, -2));
        b.requestFocus();
    }

    private void startReportWatcher() {
        try {
            android.content.IntentFilter f = new android.content.IntentFilter();
            f.addAction(Intent.ACTION_MEDIA_UNMOUNTED);
            f.addAction(Intent.ACTION_MEDIA_REMOVED);
            f.addAction(Intent.ACTION_MEDIA_BAD_REMOVAL);
            f.addAction(Intent.ACTION_MEDIA_EJECT);   // a request, not a completion - the state check decides
            reportStorageReceiver = new android.content.BroadcastReceiver() {
                @Override public void onReceive(Context c, Intent i) { onReportStorageEvent(); }
            };
            if (android.os.Build.VERSION.SDK_INT >= 33)
                registerReceiver(reportStorageReceiver, f, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(reportStorageReceiver, f);
            reportHandler = new android.os.Handler(android.os.Looper.getMainLooper());
            reportHandler.postDelayed(reportPoll, 10000);   // safety net: a missed broadcast still closes it
        } catch (Exception ignored) { }
    }

    /** On any storage event (and the 10 s safety-net poll): close the card + Self-Test only
     *  when the SELECTED kit volume is actually gone. Unrelated volume events leave it open. */
    private void onReportStorageEvent() {
        if (reportClosed || reportTxn == null) return;
        if (!kitVolumeMounted(reportTxn.vol)) {
            reportClosed = true;
            markUsbTxnConsumed();
            finish();
            return;
        }
        if (reportHandler != null) reportHandler.postDelayed(reportPoll, 10000);
    }

    private void onReportSelfTestDone(List<String[]> results) {
        if (reportClosed || isFinishing() || reportTxn == null) return;   // removed mid-check: no reopen
        if (!kitVolumeMounted(reportTxn.vol)) {
            reportClosed = true;
            markUsbTxnConsumed();
            finish();
            return;
        }
        int ok = 0, fail = 0, info = 0;
        for (String[] c : results) {
            if (c[0].equals("ok")) ok++;
            else if (c[0].equals("fail")) fail++;
            else info++;
        }
        reportList.removeAllViews();
        for (String[] c : results) {
            TextView t = new TextView(this);
            t.setText((c[0].equals("ok") ? "\u2713  " : c[0].equals("fail") ? "\u2717  " : "\u25CB  ") + c[1]);
            t.setTextSize(16);
            t.setTextColor(c[0].equals("ok") ? 0xFF3DDC84 : c[0].equals("fail") ? 0xFFFF5252 : 0xFF9AA7B4);
            t.setPadding(0, dp(5), 0, dp(5));
            reportList.addView(t);
        }
        reportSum.setText(fail == 0
                ? "Self-Test: all checks passed (" + ok + " ok, " + info + " info)"
                : "Self-Test: " + fail + " FAILED (" + ok + " ok, " + info + " info) - run Reapply to fix");
        reportSum.setTextColor(fail == 0 ? 0xFF3DDC84 : 0xFFFF5252);
    }

    @Override
    protected void onDestroy() {
        if (reportStorageReceiver != null) {
            try { unregisterReceiver(reportStorageReceiver); } catch (Exception ignored) { }
            reportStorageReceiver = null;
        }
        if (reportHandler != null) {
            reportHandler.removeCallbacks(reportPoll);
            reportHandler = null;
        }
        super.onDestroy();
    }

    // ---- 5) Self-test ------------------------------------------------------

    /**
     * Full self-check of the build, run locally on the TV (no PC, no Tailscale): the debloat list,
     * the home launcher, the device admin, every config key, the wallpaper, the YouTube button
     * mapping, Live TV, shell access and the built-in build package. Also runs automatically after
     * every "Reapply Debloat and Tweaks": the selftest_pending flag survives the launcher restart
     * and MainActivity opens this screen with auto_self_test.
     */
    private void runSelfTest(final boolean auto) {
        runSelfTestChecks(results -> runOnUiThread(() -> {
            if (!isFinishing()) showSelfTest(results, auto);
        }));
    }

    /** The self-check worker, shared by the manual Self-Test dialog and the USB completion report. */
    private void runSelfTestChecks(java.util.function.Consumer<List<String[]>> onDone) {
        new Thread(() -> {
            List<String[]> r = new ArrayList<>();    // {ok|fail|info, label}
            PackageManager pm = getPackageManager();

            // 1) Debloat: every bloat package from the list is disabled
            int dOk = 0;
            for (String p : DEBLOAT) {
                boolean off;
                try {
                    // Effective enabled state for user 0 - accounts for pm disable-user.
                    off = !pm.getApplicationInfo(p, 0).enabled;
                }
                catch (Exception e) {
                    off = true;   // not installed on this TV - nothing to disable, treat as ok
                }
                if (off) dOk++; else r.add(new String[]{"fail", "Debloat: " + p});
            }
            r.add(0, new String[]{dOk == DEBLOAT.length ? "ok" : "fail",
                    "Debloat: " + dOk + "/" + DEBLOAT.length + " bloat packages disabled"});

            // 2) Home launcher
            String home = null;
            try {
                android.content.pm.ResolveInfo ri = pm.resolveActivity(
                        new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0);
                if (ri != null && ri.activityInfo != null) home = ri.activityInfo.packageName;
            } catch (Exception ignored) { }
            r.add(new String[]{getPackageName().equals(home) ? "ok" : "fail",
                    "Home screen: " + (home == null ? "none" : home)});

            // 3) Device admin (the Reapply button needs it for pm disable-user)
            boolean admin = false;
            try {
                DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                admin = dpm != null && dpm.isAdminActive(
                        new ComponentName(getPackageName(), "com.gathin.tvhome.TvAdmin"));
            } catch (Exception ignored) { }
            r.add(new String[]{admin ? "ok" : "fail", "Device admin active (needed by Reapply)"});

            // 4) Config file and its keys
            JSONObject cfg = null;
            boolean cfgOk = configFile.isFile();
            if (cfgOk) {
                try (FileInputStream in = new FileInputStream(configFile)) {
                    cfg = new JSONObject(new String(readAll(in), StandardCharsets.UTF_8));
                } catch (Exception e) { cfgOk = false; }
            }
            r.add(new String[]{cfgOk ? "ok" : "fail", "Config file (config.json) present and readable"});
            if (cfg != null) {
                checkCfg(r, cfg, "show_stats", "Config: stats line on the home screen");
                checkCfg(r, cfg, "settings_key_panel", "Config: settings panel enabled");
                boolean hasCin = cfg.has("cinematic_home");
                r.add(new String[]{hasCin ? "ok" : "fail",
                        "Config: cinematic shelf set by theme (" + (cfg.optBoolean("cinematic_home") ? "on" : "off") + ")"});
                int dockOp = cfg.optInt("dock_opacity", 55);   // 55 = built-in default when a theme omits it
                r.add(new String[]{dockOp >= 0 && dockOp <= 100 ? "ok" : "fail",
                        "Config: dock band opacity " + dockOp + "%"});
                checkCfg(r, cfg, "wallpaper_true_color", "Config: true-color wallpaper");
                checkCfg(r, cfg, "wifi_status_color", "Config: Wi-Fi status color");
                boolean keys = false;
                try {
                    JSONArray k = cfg.optJSONArray("settings_key_keycodes");
                    if (k != null) for (int i = 0; i < k.length(); i++)
                        if (k.optInt(i, -1) == 83 || k.optInt(i, -1) == 118) keys = true;
                } catch (Exception ignored) { }
                r.add(new String[]{keys ? "ok" : "fail", "Config: settings button opens the panel (keycode 83/118)"});
                int ak = 0;
                try {
                    JSONArray a = cfg.optJSONArray("app_keys");   // format: ["4062:com.netflix.ninja", ...]
                    if (a != null) {
                        java.util.Set<String> got = new java.util.HashSet<>();
                        for (int i = 0; i < a.length(); i++) {
                            String e = a.optString(i, "");
                            int c = e.indexOf(':');
                            if (c > 0 && e.length() > c + 1) got.add(e.substring(0, c));
                        }
                        for (String k : new String[]{"190", "4062", "4159", "4099"}) if (got.contains(k)) ak++;
                    }
                } catch (Exception ignored) { }
                r.add(new String[]{ak == 4 ? "ok" : "fail",
                        "Config: remote shortcut buttons " + ak + "/4 (YouTube, Netflix, Browser, Prime)"});
                int dock = 0;
                try { JSONArray d = cfg.optJSONArray("dock_apps"); if (d != null) dock = d.length(); }
                catch (Exception ignored) { }
                r.add(new String[]{dock > 0 ? "ok" : "fail", "Config: dock has " + dock + " apps"});
                String ltv = cfg.optString("live_tv_package", "");
                r.add(new String[]{"com.tcl.tv".equals(ltv) ? "ok" : "fail",
                        "Config: Live TV package " + (ltv.isEmpty() ? "not set" : ltv)});
            } else {
                for (String l : new String[]{"Config: stats line", "Config: settings panel", "Config: cinematic home",
                        "Config: true-color wallpaper", "Config: Wi-Fi status color", "Config: settings keycodes",
                        "Config: remote shortcut buttons", "Config: dock apps", "Config: Live TV package"})
                    r.add(new String[]{"fail", l});
            }

            // 5) Wallpaper: theme-dependent - a single file, a rotating collection, or a plain background.
            File filesDir = configFile.getParentFile();
            boolean wpOk;
            String wpStatus;
            File wpFile = filesDir != null ? new File(filesDir, "wallpaper.jpg") : null;
            File[] wpImgs = filesDir != null
                    ? new File(filesDir, "wallpapers").listFiles((d, n) -> n.toLowerCase().endsWith(".jpg")
                            || n.toLowerCase().endsWith(".png") || n.toLowerCase().endsWith(".webp"))
                    : null;
            int wpCount = wpImgs == null ? 0 : wpImgs.length;
            if (cfg != null && !cfg.optBoolean("wallpaper", true)) {
                wpOk = true;
                wpStatus = "off (plain background)";
            } else if (cfg != null && cfg.optInt("wallpaper_rotation_minutes", 0) > 0) {
                wpOk = wpCount > 0;
                wpStatus = wpOk ? "rotating collection (" + wpCount + " images)"
                        : "rotation enabled but the collection is empty";
            } else if (wpFile != null && wpFile.isFile()) {
                wpOk = true;
                wpStatus = "single wallpaper";
            } else {
                // Valid state for themes without a wallpaper (Apple TV, Better Glass, Six Columns).
                wpOk = true;
                wpStatus = "plain background (active theme has no wallpaper)";
            }
            r.add(new String[]{wpOk ? "ok" : "fail", "Wallpaper: " + wpStatus});

            // 6) YouTube button: system-level mapping of keycode 190
            String ckl = null, ck190 = null;
            try {
                ckl = Settings.Global.getString(getContentResolver(), "CustomKeyList");
                ck190 = Settings.Global.getString(getContentResolver(), "CustomKey_190");
            } catch (Exception ignored) { }
            r.add(new String[]{ckl != null && ckl.contains("190") ? "ok" : "fail",
                    "System: YouTube button registered (CustomKeyList = " + (ckl == null ? "none" : ckl) + ")"});
            r.add(new String[]{ck190 != null && ck190.contains("com.google.android.youtube.tv") ? "ok" : "fail",
                    "System: YouTube button opens YouTube"});
            // TV Setup stays reachable from the remote settings key even after a debloat reset.
            String ck83 = null;
            try { ck83 = Settings.Global.getString(getContentResolver(), "CustomKey_83"); }
            catch (Exception ignored) { }
            r.add(new String[]{ckl != null && ckl.contains("83") ? "ok" : "fail",
                    "System: TV Setup button registered (settings key)"});
            r.add(new String[]{ck83 != null && ck83.contains("com.gathin.tvhome") ? "ok" : "fail",
                    "System: TV Setup button opens TV Setup"});

            // 7) Screensaver (info: the system default is fine)
            String sv = null;
            try { sv = Settings.System.getString(getContentResolver(), "screensaver_components"); }
            catch (Exception ignored) { }
            if (sv == null || sv.isEmpty()) r.add(new String[]{"info", "Screensaver: system default"});
            else r.add(new String[]{sv.contains("com.gathin.tvhome") ? "ok" : "fail", "Screensaver: " + sv});

            // 8) Live TV app
            boolean ltvOk = false;
            try {
                int st = pm.getApplicationEnabledSetting("com.tcl.tv");
                ltvOk = st != PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                        && st != PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER;
            }
            catch (Exception ignored) { }
            r.add(new String[]{ltvOk ? "ok" : "fail", "Live TV app (com.tcl.tv) installed and enabled"});

            // 9) Shell access (Reapply runs pm through it)
            r.add(new String[]{runShell("pm", "list", "packages") == 0 ? "ok" : "fail",
                    "Shell access for Reapply (pm) working"});

            // 9b) Reapply/Reset executor (daemon): full = shell rights, limited = app rights.
            // A stopped executor is a readiness note, not a build failure: the applied debloat,
            // theme and config persist without it, and the USB auto-apply shuts it down by design.
            String dState = daemonState();
            if (dState.equals("full")) r.add(new String[]{"ok", "Reapply/Reset executor running (full rights)"});
            else if (dState.equals("limited")) r.add(new String[]{"info",
                    "Reapply/Reset executor running (limited rights - package changes blocked, start over ADB for full)"});
            else r.add(new String[]{"info",
                    "Reapply/Reset executor not running (applied build persists) - use Start daemon in TV Setup when package changes are needed"});

            // 10) Built-in build package inside the APK
            boolean bp = DEBLOAT.length == KitPolicy.VETTED.length
                    && readAssetBytes("build-package/config.json") != null
                    && readAssetBytes("build-package/wallpaper.jpg") != null;
            r.add(new String[]{bp ? "ok" : "fail", "Built-in build package complete (list + theme + wallpaper)"});

            // 11) Launcher version (info)
            String ver = "?";
            try { ver = pm.getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
            r.add(new String[]{"info", "Launcher version: " + ver});

            // 12) Accessibility services (info: the firmware may clear them, the config route is active)
            String acc = null;
            try { acc = Settings.Secure.getString(getContentResolver(), "enabled_accessibility_services"); }
            catch (Exception ignored) { }
            r.add(new String[]{"info", "Accessibility services: "
                    + (acc == null || acc.isEmpty() ? "off (config route active)" : "on")});

            final List<String[]> out = r;
            try { onDone.accept(out); } catch (Exception ignored) { }
        }).start();
    }

    private void checkCfg(List<String[]> r, JSONObject cfg, String key, String label) {
        boolean got = false;
        try { got = cfg.optBoolean(key, false); } catch (Exception ignored) { }
        r.add(new String[]{got ? "ok" : "fail", label});
    }

    private void showSelfTest(List<String[]> results, boolean auto) {
        int ok = 0, fail = 0, info = 0;
        for (String[] c : results) {
            if (c[0].equals("ok")) ok++;
            else if (c[0].equals("fail")) fail++;
            else info++;
        }
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(8), dp(4), dp(8), dp(4));
        for (String[] c : results) {
            TextView t = new TextView(this);
            t.setText((c[0].equals("ok") ? "\u2713  " : c[0].equals("fail") ? "\u2717  " : "\u25CB  ") + c[1]);
            t.setTextSize(16);
            t.setTextColor(c[0].equals("ok") ? 0xFF3DDC84 : c[0].equals("fail") ? 0xFFFF5252 : 0xFF9AA7B4);
            t.setPadding(0, dp(5), 0, dp(5));
            list.addView(t);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        TextView sum = new TextView(this);
        sum.setText((auto ? "After Reapply - " : "")
                + (fail == 0 ? "All checks passed (" + ok + " ok, " + info + " info)"
                             : fail + " FAILED (" + ok + " ok, " + info + " info) - run Reapply to fix"));
        sum.setTextSize(18);
        sum.setTextColor(fail == 0 ? 0xFF3DDC84 : 0xFFFF5252);
        sum.setPadding(dp(8), 0, dp(8), dp(10));
        body.addView(sum);
        body.addView(sv, new LinearLayout.LayoutParams(-1, dp(560)));
        new AlertDialog.Builder(this)
                .setTitle(auto ? "Self-Test (after Reapply)" : "Self-Test")
                .setView(body)
                .setPositiveButton("OK", null)
                .show();
    }

    // ---- 4) Factory reset --------------------------------------------------

    private void factoryReset() {
        new AlertDialog.Builder(this)
                .setTitle("Reset TV to Factory Defaults")
                .setMessage("This erases all apps, data and settings. Continue?")
                .setPositiveButton("Reset", (d, w) -> {
                    try {
                        startActivity(new Intent("android.intent.action.FACTORY_RESET")
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (ActivityNotFoundException e) {
                        try {
                            startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                            toast("Open System > Reset > Factory data reset");
                        } catch (Exception e2) { toast("Could not open reset"); }
                    }
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---- config.json dock helpers -----------------------------------------

    private List<String> readDock() {
        List<String> dock = new ArrayList<>(java.util.Arrays.asList(
                getResources().getStringArray(R.array.dock_apps)));
        if (!configFile.isFile() || configFile.length() >= 64 * 1024) return dock;
        try (FileInputStream in = new FileInputStream(configFile)) {
            byte[] buf = new byte[(int) configFile.length()];
            int n = 0, r;
            while (n < buf.length && (r = in.read(buf, n, buf.length - n)) > 0) n += r;
            String text = new String(buf, 0, n, StandardCharsets.UTF_8);
            if (text.startsWith("\uFEFF")) text = text.substring(1);
            JSONObject json = new JSONObject(text);
            JSONArray a = json.optJSONArray("dock_apps");
            if (a != null) {
                dock.clear();
                for (int i = 0; i < a.length(); i++)
                    if (a.opt(i) instanceof String) dock.add(((String) a.opt(i)).trim());
            }
        } catch (Exception ignored) { }
        return dock;
    }

    private void writeDock(List<String> dock) {
        try {
            JSONObject json = null;
            if (configFile.isFile() && configFile.length() < 64 * 1024) {
                byte[] buf = new byte[(int) configFile.length()];
                try (FileInputStream in = new FileInputStream(configFile)) {
                    int n = 0, r;
                    while (n < buf.length && (r = in.read(buf, n, buf.length - n)) > 0) n += r;
                    json = new JSONObject(new String(buf, 0, n, StandardCharsets.UTF_8));
                }
            }
            if (json == null) json = new JSONObject();
            JSONArray a = new JSONArray();
            for (String p : dock) a.put(p);
            json.put("dock_apps", a);
            File dir = configFile.getParentFile();
            if (dir != null && !dir.exists()) dir.mkdirs();
            try (FileOutputStream out = new FileOutputStream(configFile)) {
                out.write(json.toString(2).getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) { }
    }

    private void restartHome() {
        try {
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                    .setPackage(getPackageName())
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(home);
        } catch (Exception ignored) { }
        finish();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
