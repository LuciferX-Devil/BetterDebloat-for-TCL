package com.gathin.tvhome;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Boot safety net for the debloat. The disabled-package state persists in packages.xml, so a reboot
 * never undoes the debloat - this only detects if something else re-enabled a package and tells the
 * owner what to do. It runs with the launcher's app uid, which can read package state but not change
 * it (that needs the shell-uid executor), so it reports; it never applies.
 *
 * Two entry points, same logic:
 *  - onReceive(): fires on BOOT_COMPLETED when the receiver is registered in the manifest
 *    (base.apk manifest rebuild pending - see the TV Setup daemon notes).
 *  - checkOnce(): called by MainActivity on the first home launch after boot, so the check runs on
 *    this build even without the manifest registration. Once per process, never on the UI thread.
 */
public class DebloatBootReceiver extends BroadcastReceiver {

    private static boolean sCheckedThisProcess;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            new Thread(() -> check(context.getApplicationContext())).start();
        }
    }

    /**
     * Run the debloat verification once per app process, off the UI thread. Safe to call from
     * MainActivity.onCreate on every home launch: after the first run it is a no-op until the
     * process is recreated (reboot / process death).
     */
    public static void checkOnce(final Context context) {
        if (sCheckedThisProcess) return;
        sCheckedThisProcess = true;
        final Context app = context.getApplicationContext();
        new Thread(() -> {
            // Give the package manager a moment to settle after boot.
            try { Thread.sleep(5000); } catch (InterruptedException ignored) { }
            check(app);
        }).start();
    }

    private static void check(Context context) {
        try {
            String[] list = TVSetupActivity.debloatList();
            if (list == null || list.length == 0) return;

            String disabled = exec("pm list packages -d");
            if (disabled == null) return;

            int disabledCount = 0;
            int reenabled = 0;
            int notInstalled = 0;
            StringBuilder names = new StringBuilder();
            for (String pkg : list) {
                if (disabled.contains("package:" + pkg)) { disabledCount++; continue; } // still disabled - good
                // Not disabled: only a problem if the package is actually installed on this TV.
                boolean installed;
                try {
                    context.getPackageManager().getPackageInfo(pkg, 0);
                    installed = true;
                } catch (Exception e) {
                    installed = false; // e.g. com.google.android.videos on units without Play Movies
                }
                if (installed) {
                    reenabled++;
                    if (names.length() < 300) names.append(pkg).append('\n');
                } else {
                    notInstalled++;
                }
            }

            Log.i("DebloatCheck", "debloat verify: " + disabledCount + " disabled, " + reenabled
                    + " re-enabled, " + notInstalled + " not installed (of " + list.length + ")");
            if (reenabled > 0) {
                warnOwner(context, reenabled, names.toString());
            }
        } catch (Exception ignored) {
            // Safety net only: never crash the launcher because of it.
        }
    }

    private static String exec(String cmd) {
        try {
            Process p = new ProcessBuilder("/system/bin/sh", "-c", cmd).redirectErrorStream(true).start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            p.waitFor();
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Report a broken debloat to the owner. Uses a Toast (no runtime permission needed on API 34,
     * unlike a notification) on the main thread, plus a logcat line for debugging.
     */
    private static void warnOwner(final Context context, final int count, final String packages) {
        final String msg = count + " bloatware package(s) re-enabled. TV Setup: start daemon, then Reapply Debloat.\n" + packages;
        Log.w("DebloatCheck", msg);
        new Handler(Looper.getMainLooper()).post(() ->
                Toast.makeText(context.getApplicationContext(), msg, Toast.LENGTH_LONG).show());
    }
}
