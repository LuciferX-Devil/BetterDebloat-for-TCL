package com.gathin.tvhome;

/**
 * Durable USB Reapply completion record, shared by the shell daemon (auto-kit path), the app
 * (manual USB-folder path) and the completion report. One bounded flat line, e.g.:
 *   v=1|src=auto|vol=ABCD-1234|status=completed|ok=32|fail=0|reason=-|ts=1730250000|consumed=0
 * The shell commits "completed"/"failed" only after the operation really ended; the app commits
 * "pending" before an APK self-update and "completed" once the executor confirms the tail.
 * The record is a UI hint only: it never grants shell authority or accepts commands/paths.
 * Pure Java (no Android imports) so it can be unit-tested off-device.
 */
public final class UsbTransaction {

    private UsbTransaction() {}

    public static final class Txn {
        public final String src;      // auto | manual
        public final String vol;      // the SELECTED kit volume UUID
        public final String status;   // pending | completed | failed
        public final int ok;          // packages verified disabled (-1 = unknown)
        public final int fail;        // packages not disabled (-1 = unknown)
        public final String reason;   // "-" or a fixed failure token
        public final long ts;         // unix seconds when the record was committed
        public final boolean consumed;
        public Txn(String src, String vol, String status, int ok, int fail,
                   String reason, long ts, boolean consumed) {
            this.src = src; this.vol = vol; this.status = status;
            this.ok = ok; this.fail = fail; this.reason = reason;
            this.ts = ts; this.consumed = consumed;
        }
    }

    public static String encode(String src, String vol, String status, int ok, int fail,
                                String reason, long ts, boolean consumed) {
        return "v=1|src=" + src + "|vol=" + vol + "|status=" + status
                + "|ok=" + ok + "|fail=" + fail + "|reason=" + reason
                + "|ts=" + ts + "|consumed=" + (consumed ? 1 : 0);
    }

    /** Strict decode; null when the line is absent or malformed (never trust it for success). */
    public static Txn decode(String line) {
        if (line == null) return null;
        line = line.trim();
        if (line.isEmpty() || line.length() > 512 || line.indexOf('\n') >= 0) return null;
        String src = null, vol = null, status = null, reason = "-";
        int ok = -1, fail = -1;
        long ts = -1;
        boolean consumed = false;
        for (String tok : line.split("\\|", -1)) {
            int c = tok.indexOf('=');
            if (c <= 0) return null;
            String k = tok.substring(0, c), v = tok.substring(c + 1);
            switch (k) {
                case "v": if (!v.equals("1")) return null; break;
                case "src": if (!v.equals("auto") && !v.equals("manual")) return null; src = v; break;
                case "vol": if (!v.matches("^[A-Za-z0-9_-]{1,32}$")) return null; vol = v; break;
                case "status":
                    if (!v.equals("pending") && !v.equals("completed") && !v.equals("failed")) return null;
                    status = v; break;
                case "ok":
                    if (v.equals("-") || v.equals("-1")) ok = -1;
                    else if (v.matches("^[0-9]{1,4}$")) ok = Integer.parseInt(v);
                    else return null; break;
                case "fail":
                    if (v.equals("-") || v.equals("-1")) fail = -1;
                    else if (v.matches("^[0-9]{1,4}$")) fail = Integer.parseInt(v);
                    else return null; break;
                case "reason": if (v.length() > 64 || !v.matches("^[A-Za-z0-9_=-]*$")) return null; reason = v; break;
                case "ts": if (!v.matches("^[0-9]{1,11}$")) return null; ts = Long.parseLong(v); break;
                case "consumed": if (!v.equals("0") && !v.equals("1")) return null; consumed = v.equals("1"); break;
                default: return null;
            }
        }
        if (src == null || vol == null || status == null || ts <= 0) return null;
        if (ts > System.currentTimeMillis() / 1000L + 3600) return null;   // not from the future
        return new Txn(src, vol, status, ok, fail, reason, ts, consumed);
    }

    /** Read a bounded protocol file, accounting for bytes returned by each read. */
    public static String readRecord(java.io.File f, int maxLen) {
        if (f == null || maxLen < 0 || !f.isFile() || f.length() > maxLen) return null;
        try (java.io.FileInputStream in = new java.io.FileInputStream(f);
             java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
            byte[] buf = new byte[256];
            int count;
            while ((count = in.read(buf)) != -1) {
                if (out.size() + count > maxLen) return null;
                out.write(buf, 0, count);
            }
            return out.toString(java.nio.charset.StandardCharsets.US_ASCII.name());
        } catch (Exception e) { return null; }
    }

    /** Mark one validated receipt consumed, without changing any other field. */
    public static boolean consumeRecord(java.io.File file) {
        Txn t = decode(readRecord(file, 1024));
        if (t == null) return false;
        if (t.consumed) return true;
        try (java.io.FileOutputStream out = new java.io.FileOutputStream(file)) {
            out.write(encode(t.src, t.vol, t.status, t.ok, t.fail, t.reason, t.ts, true)
                    .getBytes(java.nio.charset.StandardCharsets.US_ASCII));
            return true;
        } catch (Exception e) { return false; }
    }

    /** Ignore pending writes, archived receipts and other files. */
    public static boolean isRecordName(String name) {
        return FILE_LEGACY.equals(name) || (name != null && name.matches("usb-txn-[0-9]+\\.json"));
    }

    /** The well-known legacy record name (kept for backward compatibility). */
    public static final String FILE_LEGACY = "usb-transaction.json";
    /** New records use a fresh per-apply name (FILE_TS_PREFIX + unix-ts + ".json"). */
    public static final String FILE_TS_PREFIX = "usb-txn-";

    /**
     * Find the most recent transaction record in the directory. Considers the legacy
     * {@link #FILE_LEGACY} and every {@link #FILE_TS_PREFIX}<ts>.json. A fresh per-apply name
     * identifies each transaction independently.
     * Returns the file with the newest lastModified(); null when none exist.
     */
    public static java.io.File findLatest(java.io.File dir) {
        if (dir == null || !dir.isDirectory()) return null;
        java.io.File[] all = dir.listFiles((d, name) ->
                isRecordName(name));
        if (all == null || all.length == 0) return null;
        java.io.File best = null;
        long bestM = -1;
        for (java.io.File f : all) {
            if (f == null || !f.isFile()) continue;
            long m = f.lastModified();
            if (m > bestM) { bestM = m; best = f; }
        }
        return best;
    }

    /** Route/report a transaction only while it is fresh (24 h) and unconsumed. */
    public static boolean isFresh(Txn t, long nowSec) {
        return t != null && !t.consumed && t.ts > 0 && nowSec - t.ts >= 0 && nowSec - t.ts <= 86400;
    }

    /**
     * Resolve the report status. "completed"/"failed" pass through. A "pending" record (the app
     * was killed by the APK self-update) resolves only after the 120 s self-update window, and
     * only to "completed" when a fresh executor "apply" result proves the tail finished.
     */
    public static String resolveStatus(Txn t, boolean freshApplyResult, long nowSec) {
        if (t == null) return null;
        if (t.status.equals("completed") || t.status.equals("failed")) return t.status;
        if (nowSec - t.ts <= 120) return "pending";
        return freshApplyResult ? "completed" : "interrupted";
    }
}
