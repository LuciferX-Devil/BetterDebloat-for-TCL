package com.gathin.tvhome;

import android.content.Context;
import android.os.Build;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;

import java.io.File;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * USB kit auto-setup, shared by every entry point so the debloat applies the same way whether the
 * trigger is the launcher starting (tvhome is Home) or a boot / USB-stick broadcast (the stock
 * launcher is Home, e.g. right after a Reset). One-shot: it runs when a removable volume is mounted
 * and the kit has not been applied yet, then sets a persistent marker so it does not run again
 * until a Reset clears it.
 */
public final class UsbAutoApply {

    private UsbAutoApply() {}

    /** Process-wide guard so the launcher start and a boot/media broadcast never apply at once. */
    private static final AtomicBoolean sRunning = new AtomicBoolean(false);

    /** True if the kit was already applied (marker persists across home restarts; Reset clears it). */
    public static boolean isApplied(Context ctx) {
        File ext = ctx.getExternalFilesDir(null);
        return ext != null && new File(ext, "usb_applied").isFile();
    }

    /** True if a removable (USB) volume is mounted. Needs no storage permission. */
    public static boolean hasRemovableVolume(Context ctx) {
        try {
            if (Build.VERSION.SDK_INT < 29) return false;   // getStorageVolumes() is API 29+
            StorageManager sm = (StorageManager) ctx.getSystemService(Context.STORAGE_SERVICE);
            if (sm == null) return false;
            for (StorageVolume v : sm.getStorageVolumes()) {
                if (v.isRemovable() && "mounted".equals(v.getState())) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    /**
     * Apply the kit if the conditions are met (a stick is in and it has not been applied yet).
     * Retries 3x/15s so a fresh TV's one-time TV-debugging approval can be accepted. Returns the
     * executor's result line, or null if it did not apply (no stick / no kit / service failed).
     * Safe to call from any thread.
     */
    public static String runIfReady(Context ctx) {
        if (isApplied(ctx)) return null;
        if (isUsbOperationPending(ctx)) return null;
        if (!hasRemovableVolume(ctx)) return null;
        if (!sRunning.compareAndSet(false, true)) return null;   // another entry point is applying
        try {
            String res = null;
            for (int attempt = 1; attempt <= 3 && res == null; attempt++) {
                res = TVSetupActivity.runUsbApply(ctx);
                if (res == null && attempt < 3) {
                    // First run on a fresh TV needs the one-time TV-debugging approval for the service;
                    // give the owner time to accept it, then retry.
                    try { Thread.sleep(15000); } catch (InterruptedException ignored) {}
                }
            }
            if (res == null) return null;                          // service could not start
            if (res.contains("none=1")) return null;               // stick present, no kit
            if (res.contains("rejected") || res.contains("error=") || !res.contains("ok=")) {
                // Kit rejected (bad path / unknown package). No markers, no success toast; a
                // corrected stick can be retried (the applied marker is intentionally NOT set).
                android.util.Log.w("CysUsb", "USB kit rejected: " + res);
                return null;
            }
            markApplied(ctx);
            return res;
        } finally {
            sRunning.set(false);
        }
    }

    /** A package update restarts this process while the shell still owns the USB transaction.
     * This external timestamp only delays retries; it never grants execution rights.
     * A killed executor cannot block retries forever: the hint expires after two minutes.
     */
    private static boolean isUsbOperationPending(Context ctx) {
        try {
            File ext = ctx.getExternalFilesDir(null);
            if (ext == null) return false;
            File busy = new File(ext, "usb_in_progress");
            if (!busy.isFile() || busy.length() > 32) return false;
            long ts = Long.parseLong(new String(java.nio.file.Files.readAllBytes(busy.toPath()),
                    java.nio.charset.StandardCharsets.US_ASCII).trim());
            long age = System.currentTimeMillis() / 1000L - ts;
            return age >= 0 && age <= 120;
        } catch (Exception e) { return false; }
    }

    /** Persist the "applied" markers so the auto-apply does not run again until a Reset. */
    private static void markApplied(Context ctx) {
        try {
            File ext = ctx.getExternalFilesDir(null);
            if (ext == null) return;
            new File(ext, "usb_applied").createNewFile();
            new File(ext, "build_applied").createNewFile();   // TV Setup shows the full customization list
        } catch (Exception ignored) {}
    }

    /** Turn a USB-apply result line into a short status string for a toast. */
    public static String describeResult(String res) {
        int ok = -1, fail = -1;
        for (String tok : res.split("\\s+")) {
            if (tok.startsWith("ok=")) { try { ok = Integer.parseInt(tok.substring(3)); } catch (Exception ignored) {} }
            if (tok.startsWith("fail=")) { try { fail = Integer.parseInt(tok.substring(3)); } catch (Exception ignored) {} }
        }
        if (ok < 0) return "done";
        return ok + " packages disabled" + (fail > 0 ? ", " + fail + " skipped" : "") + ", home set, service stopped";
    }
}
