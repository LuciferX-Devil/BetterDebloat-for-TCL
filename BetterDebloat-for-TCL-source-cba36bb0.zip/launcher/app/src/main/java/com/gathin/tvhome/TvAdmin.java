package com.gathin.tvhome;

import android.app.admin.DeviceAdminReceiver;

/**
 * Lets the launcher act as the device owner (set once over adb: dpm set-device-owner
 * com.gathin.tvhome/.TvAdmin). As device owner it may change the enabled state of other
 * packages (pm disable-user) and read the debloat list, so the TV can re-apply its own
 * debloat without a PC.
 */
public class TvAdmin extends DeviceAdminReceiver {
}
