package com.gathin.tvhome;

import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.interfaces.*;
import java.security.spec.*;
import java.util.Base64;

/** Call only with context.getFilesDir(): private credentials never belong on USB/shared storage. */
public final class AdbIdentity {
    private AdbIdentity() {}
    public static synchronized KeyPair loadOrCreate(File appPrivateDirectory)throws IOException,GeneralSecurityException {
        if(!appPrivateDirectory.isDirectory())throw new IOException("App-private directory missing");
        File file=new File(appPrivateDirectory,"cys-adb-identity.pk8");
        if(file.isFile()){
            PrivateKey key=AdbShellClient.readKey(file);return new KeyPair(publicFrom(key),key);
        }
        KeyPairGenerator generator=KeyPairGenerator.getInstance("RSA");generator.initialize(2048);KeyPair pair=generator.generateKeyPair();
        File pending=new File(appPrivateDirectory,"cys-adb-identity.pk8.pending");
        if(!pending.createNewFile())throw new IOException("Identity creation already pending");
        try {
            if(!pending.setReadable(false,false)||!pending.setWritable(false,false)||!pending.setReadable(true,true)||!pending.setWritable(true,true))throw new IOException("Cannot restrict identity permissions");
            try(FileOutputStream output=new FileOutputStream(pending)){output.write(pair.getPrivate().getEncoded());output.getFD().sync();}
            if(!pending.renameTo(file))throw new IOException("Cannot persist app-private identity");return pair;
        }finally {if(pending.exists())pending.delete();}
    }
    public static PublicKey publicFrom(PrivateKey privateKey)throws GeneralSecurityException {
        RSAPrivateCrtKeySpec key=KeyFactory.getInstance("RSA").getKeySpec(privateKey,RSAPrivateCrtKeySpec.class);
        return KeyFactory.getInstance("RSA").generatePublic(new RSAPublicKeySpec(key.getModulus(),key.getPublicExponent()));
    }
    private static void put32(byte[] b,int offset,int n){for(int i=0;i<4;i++)b[offset+i]=(byte)(n>>>(8*i));}
    private static void putLE(byte[] b,int offset,int size,BigInteger value){
        byte[] be=value.toByteArray();for(int i=0;i<size;i++)b[offset+i]=i<be.length?be[be.length-1-i]:0;
    }
    /** ADB's 524-byte Android RSAPublicKey structure, base64 + comment + trailing NUL. PUBLIC DATA ONLY. */
    public static byte[] publicKeyPayload(PublicKey publicKey)throws GeneralSecurityException {
        if(!(publicKey instanceof RSAPublicKey))throw new InvalidKeyException("RSA public key required");
        RSAPublicKey key=(RSAPublicKey)publicKey;BigInteger n=key.getModulus(),e=key.getPublicExponent();
        if(n.bitLength()!=2048||e.bitLength()>32)throw new InvalidKeyException("ADB requires 2048-bit RSA and 32-bit exponent");
        BigInteger base=BigInteger.ONE.shiftLeft(32);BigInteger n0inv=base.subtract(n.mod(base).modInverse(base));
        byte[] binary=new byte[524];put32(binary,0,64);put32(binary,4,n0inv.intValue());putLE(binary,8,256,n);
        putLE(binary,264,256,BigInteger.ONE.shiftLeft(4096).mod(n));put32(binary,520,e.intValue());
        return (Base64.getEncoder().encodeToString(binary)+" cys-tv-app\0").getBytes(StandardCharsets.US_ASCII);
    }
}
