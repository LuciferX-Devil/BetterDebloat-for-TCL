package com.gathin.tvhome;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Trusted-input policy for the debloat package lists, shared by the GUI Reapply path and the
 * USB auto-apply. Pure Java (no Android imports) so it can be unit-tested off-device.
 *
 * Two levels:
 *  - VETTED: the built-in 33-entry allowlist. USB auto-apply only ever accepts lists made up of
 *    these entries - a substituted kit that names anything else is rejected wholesale.
 *  - FORMAT: a well-formed Android package name. The owner's manual GUI list may contain other
 *    well-formed packages, but the UI confirms each non-vetted entry explicitly first.
 */
public final class KitPolicy {

    private KitPolicy() {}

    /** The vetted built-in debloat allowlist - must stay in sync with TVSetupActivity.DEBLOAT. */
    public static final String[] VETTED = {
            "android.autoinstalls.config.google.gtvpai",
            "com.android.adservices.api",
            "com.android.federatedcompute.services",
            "com.android.ondevicepersonalization.services",
            "com.android.tv.feedbackconsent",
            "com.app.mlounge",
            "com.google.android.feedback",
            "com.google.android.partnersetup",
            "com.google.android.play.games",
            "com.google.android.videos",
            "com.google.android.tungsten.setupwraith",
            "com.google.android.youtube.tvmusic",
            "com.mediatek.airplaydaemon",
            "com.tcl.airplay2",
            "com.tcl.channelplus",
            "com.tcl.dashboard",
            "com.tcl.esticker",
            "com.tcl.exhibit",
            "com.tcl.guard",
            "com.tcl.interactive",
            "com.tcl.logkit",
            "com.tcl.magiconnectfree",
            "com.tcl.messagebox",
            "com.tcl.ocean.instructions",
            "com.tcl.partnercustomizer",
            "com.tcl.repairguide",
            "com.tcl.smartalexa",
            "com.tcl.ttvs",
            "com.tcl.tv.tclhome_passive",
            "com.tcl.usercenter",
            "com.tcl.waterfall.overseas",
            "com.google.android.katniss",
            "com.google.android.tv.remote.service",
    };

    /** A well-formed Android package name (the only thing a list entry may look like). */
    public static boolean isWellFormedPackageName(String s) {
        if (s == null || s.isEmpty() || s.length() > 255) return false;
        char first = s.charAt(0);
        if (first == '.' || (first >= '0' && first <= '9')) return false;   // no leading dot/digit
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
                       || (c >= '0' && c <= '9') || c == '_' || c == '.';
            if (!ok) return false;
            if (c == '.') {
                if (i + 1 >= s.length() || s.charAt(i + 1) == '.') return false;
            }
        }
        return true;
    }

    /** Split a raw list into trimmed non-empty entries, dropping blank lines and # comments. */
    public static List<String> entries(String[] raw) {
        List<String> out = new ArrayList<>();
        if (raw == null) return out;
        for (String r : raw) {
            if (r == null) continue;
            String e = r.trim();
            if (e.isEmpty() || e.startsWith("#")) continue;
            out.add(e);
        }
        return out;
    }

    /** True if every entry is a vetted allowlist member (USB auto-apply requirement). */
    public static boolean isAllVetted(List<String> entries) {
        Set<String> vetted = new HashSet<>(Arrays.asList(VETTED));
        for (String e : entries) if (!vetted.contains(e)) return false;
        return true;
    }

    /** True if every entry is at least a well-formed package name (GUI list requirement). */
    public static boolean isAllWellFormed(List<String> entries) {
        for (String e : entries) if (!isWellFormedPackageName(e)) return false;
        return true;
    }

    /** The entries of a list that are not on the vetted allowlist (for the GUI confirmation). */
    public static List<String> nonVetted(List<String> entries) {
        Set<String> vetted = new HashSet<>(Arrays.asList(VETTED));
        List<String> out = new ArrayList<>();
        for (String e : entries) if (!vetted.contains(e)) out.add(e);
        return out;
    }
}
