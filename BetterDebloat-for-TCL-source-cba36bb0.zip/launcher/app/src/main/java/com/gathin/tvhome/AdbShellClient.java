package com.gathin.tvhome;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import javax.crypto.Cipher;
import javax.net.ssl.*;

/** Isolated, Android-compatible protocol candidate. No Android UI dependencies or embedded keys. */
public final class AdbShellClient {
    private static final int LIMIT=1024*1024, VERSION=0x01000001;
    private static final int CNXN=tag("CNXN"),AUTH=tag("AUTH"),STLS=tag("STLS"),OPEN=tag("OPEN"),OKAY=tag("OKAY"),WRTE=tag("WRTE"),CLSE=tag("CLSE");
    private final PrivateKey key;
    private final X509Certificate certificate;
    private final String peerPin;
    private final boolean allowPublicKeyApproval;
    private InputStream in;
    private OutputStream out;
    private boolean skipChecksum;
    private boolean awaitingConnect;
    public AdbShellClient(PrivateKey key,X509Certificate certificate,String peerPin) {
        this(key,certificate,peerPin,false);
    }
    /** Set approval=true only for an owner-triggered setup/Start action; TV approval is still required. */
    public AdbShellClient(PrivateKey key,X509Certificate certificate,String peerPin,boolean approval) {
        this.key=key;this.certificate=certificate;this.peerPin=peerPin;this.allowPublicKeyApproval=approval;
    }
    private static int tag(String s){byte[] b=s.getBytes(StandardCharsets.US_ASCII);return get(b,0);}
    private static int get(byte[] b,int p){return (b[p]&255)|((b[p+1]&255)<<8)|((b[p+2]&255)<<16)|((b[p+3]&255)<<24);}
    private static void put(byte[] b,int p,int v){for(int i=0;i<4;i++)b[p+i]=(byte)(v>>>(8*i));}
    private static int sum(byte[] b){int n=0;for(byte v:b)n+=v&255;return n;}
    private static IOException error(String s){return new IOException(s);}
    private byte[] exact(int n)throws IOException {
        byte[] b=new byte[n];int p=0;
        while(p<n){int k=in.read(b,p,n-p);if(k<0)throw error("Truncated ADB packet");if(k==0)continue;p+=k;}return b;
    }
    private static final class Packet {
        int command,a,b;byte[] data;
        Packet(int command,int a,int b,byte[] data){this.command=command;this.a=a;this.b=b;this.data=data;}
    }
    private Packet receive()throws IOException {
        byte[] h=exact(24);int cmd=get(h,0),a=get(h,4),n=get(h,12);
        if(get(h,20)!=(cmd^0xffffffff)||n<0||n>LIMIT)throw error("Invalid ADB header");
        byte[] data=exact(n);
        // Modern adbd learns our version from host CNXN and can zero AUTH's checksum
        // before it sends its own CNXN. Authentication still verifies the signed token.
        boolean modernAuthZero = awaitingConnect && (cmd==AUTH || cmd==STLS) && get(h,16)==0;
        if(!skipChecksum && !(cmd==CNXN&&a>=VERSION) && !modernAuthZero && get(h,16)!=sum(data))
            throw error("ADB checksum mismatch (command=" + Integer.toHexString(cmd) + ", length=" + n + ")");
        return new Packet(cmd,a,get(h,8),data);
    }
    private void send(int cmd,int a,int b,byte[] data)throws IOException {
        if(data.length>LIMIT)throw error("Payload too large");byte[] h=new byte[24];
        put(h,0,cmd);put(h,4,a);put(h,8,b);put(h,12,data.length);put(h,16,sum(data));put(h,20,cmd^0xffffffff);
        out.write(h);out.write(data);out.flush();
    }
    private void send(int cmd,int a,int b)throws IOException {send(cmd,a,b,new byte[0]);}
    private byte[] signToken(byte[] token)throws GeneralSecurityException,IOException {
        if(token.length!=20)throw error("Expected 20-byte AUTH token");
        // SHA1 DigestInfo followed by the supplied digest. Do not SHA1(token) again.
        byte[] prefix={0x30,0x21,0x30,0x09,0x06,0x05,0x2b,0x0e,0x03,0x02,0x1a,0x05,0x00,0x04,0x14};
        byte[] digestInfo=Arrays.copyOf(prefix,prefix.length+20);System.arraycopy(token,0,digestInfo,prefix.length,20);
        Cipher rsa=Cipher.getInstance("RSA/ECB/PKCS1Padding");rsa.init(Cipher.ENCRYPT_MODE,key);return rsa.doFinal(digestInfo);
    }
    private SSLSocket upgrade(Socket socket,String host,int port)throws GeneralSecurityException,IOException {
        if(certificate==null||peerPin==null||!peerPin.matches("[0-9a-f]{64}"))throw error("TLS needs client certificate and trusted peer SHA256 pin");
        KeyStore store=KeyStore.getInstance(KeyStore.getDefaultType());store.load(null,null);
        store.setKeyEntry("adb",key,new char[0],new java.security.cert.Certificate[]{certificate});
        KeyManagerFactory km=KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());km.init(store,new char[0]);
        X509TrustManager pinned=new X509TrustManager(){
            public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}
            public void checkClientTrusted(X509Certificate[] chain,String auth)throws CertificateException {throw new CertificateException("Client role only");}
            public void checkServerTrusted(X509Certificate[] chain,String auth)throws CertificateException {
                if(chain==null||chain.length==0)throw new CertificateException("Missing peer certificate");
                try {byte[] digest=MessageDigest.getInstance("SHA-256").digest(chain[0].getEncoded());
                    StringBuilder hex=new StringBuilder();for(byte v:digest)hex.append(String.format(Locale.ROOT,"%02x",v&255));
                    if(!MessageDigest.isEqual(hex.toString().getBytes(StandardCharsets.US_ASCII),peerPin.getBytes(StandardCharsets.US_ASCII)))throw new CertificateException("Peer pin mismatch");
                }catch(GeneralSecurityException e){throw new CertificateException(e);}
            }
        };
        SSLContext context=SSLContext.getInstance("TLS");context.init(km.getKeyManagers(),new TrustManager[]{pinned},null);
        SSLSocket ssl=(SSLSocket)context.getSocketFactory().createSocket(socket,host,port,true);
        ssl.setSoTimeout(8000);ssl.startHandshake();return ssl;
    }
    /** Transport success alone does not imply the remote shell command's exit code was zero. */
    public byte[] shell(String host,int port,String command)throws IOException,GeneralSecurityException {
        if(command.indexOf('\0')>=0)throw error("NUL in command");
        Socket socket=new Socket();SSLSocket ssl=null;
        // Socket.close is a portable Android-compatible hard deadline for connect/read/write/TLS.
        Timer timer=new Timer(true);timer.schedule(new TimerTask(){public void run(){try{socket.close();}catch(IOException ignored){}}},30000);
        try {
            socket.connect(new InetSocketAddress(host,port),8000);socket.setSoTimeout(8000);
            in=socket.getInputStream();out=socket.getOutputStream();skipChecksum=false;awaitingConnect=true;
            send(CNXN,VERSION,LIMIT,"host::features=cmd\0".getBytes(StandardCharsets.UTF_8));
            boolean signed=false,publicSent=false,secure=false,connected=false;int peerMax=4096;
            for(int i=0;i<8&&!connected;i++){
                Packet p=receive();
                if(p.command==CNXN){if(p.a<0x01000000||p.b<=0)throw error("Invalid CNXN");skipChecksum=p.a>=VERSION;peerMax=p.b;connected=true;awaitingConnect=false;}
                else if(p.command==AUTH){
                    if(secure||p.a!=1||p.data.length!=20)throw error("Client key not authorized or invalid AUTH");
                    if(!signed){send(AUTH,2,0,signToken(p.data));signed=true;}
                    else if(allowPublicKeyApproval&&!publicSent){
                        send(AUTH,3,0,AdbIdentity.publicKeyPayload(AdbIdentity.publicFrom(key)));publicSent=true;socket.setSoTimeout(25000);
                    }else throw error("Client key not authorized; TV approval required");
                }
                else if(p.command==STLS){if(secure||p.a<0x01000000||p.data.length!=0)throw error("Invalid/repeated STLS");send(STLS,0x01000000,0);ssl=upgrade(socket,host,port);in=ssl.getInputStream();out=ssl.getOutputStream();secure=true;}
                else throw error("Expected AUTH, STLS or CNXN");
            }
            if(!connected)throw error("Handshake incomplete");
            byte[] service=("shell:"+command+"\0").getBytes(StandardCharsets.UTF_8);
            if(service.length>peerMax)throw error("Service exceeds peer payload limit");
            // A real TV may take >8s to scan old processes and start the daemon.
            // Keep the 30s whole-operation deadline; allow bounded shell startup latency.
            socket.setSoTimeout(25000);if(ssl!=null)ssl.setSoTimeout(25000);
            send(OPEN,1,0,service);
            int remote=0;boolean opened=false;ByteArrayOutputStream result=new ByteArrayOutputStream();
            for(int i=0;i<4096;i++){
                Packet p=receive();if(p.b!=1)throw error("Wrong local stream ID");
                if(p.command==OKAY){if(opened||p.a==0||p.data.length!=0)throw error("Invalid OPEN acknowledgment");remote=p.a;opened=true;}
                else if(p.command==WRTE){if(!opened||p.a!=remote)throw error("Invalid WRTE stream");if(result.size()+p.data.length>LIMIT)throw error("Shell output limit");result.write(p.data);send(OKAY,1,remote);}
                else if(p.command==CLSE){if(!opened||p.a!=remote||p.data.length!=0)throw error("Shell rejected/invalid close");send(CLSE,1,remote);return result.toByteArray();}
                else throw error("Unexpected shell packet");
            }
            throw error("Packet count limit");
        }finally {timer.cancel();if(ssl!=null)try{ssl.close();}catch(IOException ignored){}socket.close();}
    }
    private static final String START_FULL_DAEMON = "if [ \"$(id -u)\" != 2000 ]; then echo CYS_WRONG_UID; exit 77; fi; f=/storage/emulated/0/Android/data/com.gathin.tvhome/files; d=/data/local/tmp/cys-daemon.d; [ ! -L \"$d\" ] || exit 80; if [ -e \"$d\" ]; then [ \"$(stat -c %u \"$d\")\" = 2000 ] || exit 80; fi; umask 077; mkdir -p \"$d\" && chmod 700 \"$d\" || exit 80; t=\"$d/.script-$$\"; cp \"$f/daemon-script.sh\" \"$t\" || exit 81; h=$(sha256sum \"$t\"); if [ \"${h%% *}\" != __SCRIPT_SHA256__ ]; then rm -f \"$t\"; echo CYS_SCRIPT_HASH_MISMATCH; exit 82; fi; chmod 600 \"$t\" && mv -f \"$t\" \"$d/cys-daemon.sh\" || exit 83; for proc in /proc/[0-9]*; do cl=$(tr '\\000' ' ' < \"$proc/cmdline\" 2>/dev/null); case \"$cl\" in \"sh /data/local/tmp/cys-daemon.sh \"*|\"sh /data/local/tmp/cys-daemon.d/cys-daemon.sh \"*|\"/system/bin/sh /data/local/tmp/cys-daemon.sh \"*|\"/system/bin/sh /data/local/tmp/cys-daemon.d/cys-daemon.sh \"*) kill \"${proc##*/}\" 2>/dev/null;; esac; done; now=$(date +%s); setsid sh \"$d/cys-daemon.sh\" </dev/null >/data/local/tmp/cys-daemon.log 2>&1 & sleep 2; p=$(cat \"$f/daemon-ping.txt\" 2>/dev/null); u=$(cat \"$f/daemon-uid.txt\" 2>/dev/null); case \"$p\" in ''|*[!0-9]*) p=0;; esac; end=$(date +%s); if [ \"$u\" = 2000 ] && [ \"$p\" -ge \"$now\" ] && [ \"$p\" -le \"$end\" ]; then echo CYS_FULL_DAEMON_READY; else echo CYS_DAEMON_NOT_READY; exit 79; fi";
    /** Requires an adbd shell AND a fresh shell-UID daemon heartbeat; never app-UID fallback. */
    public byte[] startFullDaemon(String host,int port,Runnable stopOwnLimitedDaemons,String scriptSha256)throws IOException,GeneralSecurityException {
        // Android caller MUST run its existing killAppDaemons before any shell start.
        if(stopOwnLimitedDaemons==null)throw error("App-owned daemon cleanup callback required");
        stopOwnLimitedDaemons.run();
        if(scriptSha256==null||!scriptSha256.matches("[0-9a-f]{64}"))throw error("Trusted script SHA256 required");
        byte[] output=shell(host,port,START_FULL_DAEMON.replace("__SCRIPT_SHA256__",scriptSha256));
        String result=new String(output,StandardCharsets.US_ASCII);
        if(!java.util.regex.Pattern.compile("(?m)^CYS_FULL_DAEMON_READY\\r?$").matcher(result).find())
            throw error("Full-rights daemon did not confirm readiness");
        return output;
    }
    public static PrivateKey readKey(File file)throws IOException,GeneralSecurityException {
        byte[] b=readFile(file);String s=new String(b,StandardCharsets.US_ASCII);
        if(s.contains("BEGIN PRIVATE KEY")){s=s.replace("-----BEGIN PRIVATE KEY-----","").replace("-----END PRIVATE KEY-----","").replaceAll("\\s","");b=Base64.getDecoder().decode(s);}
        return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(b));
    }
    private static byte[] readFile(File file)throws IOException {
        try(InputStream input=new FileInputStream(file);ByteArrayOutputStream output=new ByteArrayOutputStream()){
            byte[] b=new byte[4096];for(int n;(n=input.read(b))>=0;){if(output.size()+n>16384)throw error("Credential file too large");output.write(b,0,n);}return output.toByteArray();
        }
    }
    public static X509Certificate readCertificate(File file)throws IOException,CertificateException {
        try(InputStream input=new FileInputStream(file)){return (X509Certificate)CertificateFactory.getInstance("X.509").generateCertificate(input);}
    }
    public static void main(String[] args)throws Exception {
        if(args.length<3)throw new IllegalArgumentException("IP PORT KEY_PEM [COMMAND] [CERT_PEM PEER_SHA256]");
        AdbShellClient client=new AdbShellClient(readKey(new File(args[2])),args.length>5?readCertificate(new File(args[4])):null,args.length>5?args[5]:null);
        String command=args.length>3?args[3]:"id -u";
        if(command.equals("--start-daemon"))throw error("Use startFullDaemon with the app-owned daemon cleanup callback");
        System.out.write(client.shell(args[0],Integer.parseInt(args[1]),command));
    }
}
