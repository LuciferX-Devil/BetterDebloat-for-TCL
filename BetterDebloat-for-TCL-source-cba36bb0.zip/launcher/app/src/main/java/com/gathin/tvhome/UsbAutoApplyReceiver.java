package com.gathin.tvhome;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

/**
 * Fires the USB kit auto-apply from system broadcasts, so the debloat applies even when the stock
 * launcher is Home (tvhome not running) - e.g. right after a Reset. Triggers:
 *   - BOOT_COMPLETED: the stick is in when the TV boots.
 *   - MEDIA_MOUNTED / MEDIA_UNMOUNTED: a stick is plugged in (or out and back in) while it runs.
 * The work runs on a background thread via goAsync() so the short-lived receiver does not block.
 */
public class UsbAutoApplyReceiver extends BroadcastReceiver {
    private static final String TAG = "CysUsb";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action == null) return;
        boolean boot = Intent.ACTION_BOOT_COMPLETED.equals(action);
        boolean mounted = Intent.ACTION_MEDIA_MOUNTED.equals(action);
        boolean unmounted = Intent.ACTION_MEDIA_UNMOUNTED.equals(action);
        if (!boot && !mounted && !unmounted) return;
        Log.i(TAG, "receiver action=" + action + " scheme=" + intent.getScheme());
        // Removal is not an apply trigger. The next MOUNTED event will check readiness.
        if (unmounted) return;

        final Context app = context.getApplicationContext();
        final PendingResult result = goAsync();
        new Thread(() -> {
            try {
                // Let the boot / mount fully settle before the daemon scans the volumes.
                try { Thread.sleep(boot ? 8000L : 3000L); } catch (InterruptedException ignored) {}
                String res = UsbAutoApply.runIfReady(app);
                Log.i(TAG, "receiver completed result=" + (res == null ? "not applied" : res));
                if (res != null) {
                    final String msg = "USB setup applied: " + UsbAutoApply.describeResult(res);
                    new Handler(Looper.getMainLooper()).post(() ->
                            Toast.makeText(app, msg, Toast.LENGTH_LONG).show());
                }
            } catch (Exception e) {
                Log.e(TAG, "receiver failed", e);
            } finally {
                result.finish();
            }
        }, "UsbAutoApplyRx").start();
    }
}
