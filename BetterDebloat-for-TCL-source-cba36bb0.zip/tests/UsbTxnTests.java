
import com.gathin.tvhome.UsbTransaction;
import com.gathin.tvhome.KitPolicy;
import java.util.*;

public class UsbTxnTests {
    static int pass = 0, fail = 0;
    static void check(String name, boolean cond) {
        if (cond) { pass++; } else { fail++; System.out.println("FAIL: " + name); }
    }
    static void writeF(java.io.File f, String s) throws Exception {
        java.nio.file.Files.write(f.toPath(), s.getBytes(java.nio.charset.StandardCharsets.US_ASCII));
    }
    public static void main(String[] args) {
        long now = System.currentTimeMillis() / 1000L;

        // 1) round-trip auto success
        String line = UsbTransaction.encode("auto", "ABCD-1234", "completed", 32, 0, "-", now, false);
        UsbTransaction.Txn t = UsbTransaction.decode(line);
        check("roundtrip nonnull", t != null);
        check("roundtrip src", t.src.equals("auto"));
        check("roundtrip vol", t.vol.equals("ABCD-1234"));
        check("roundtrip status", t.status.equals("completed"));
        check("roundtrip ok", t.ok == 32);
        check("roundtrip fail", t.fail == 0);
        check("roundtrip ts", t.ts == now);
        check("roundtrip consumed", !t.consumed);

        // 2) round-trip manual pending consumed
        UsbTransaction.Txn m = UsbTransaction.decode(
                UsbTransaction.encode("manual", "REPL-UUID", "pending", -1, -1, "-", now, true));
        check("manual pending", m != null && m.status.equals("pending") && m.consumed && m.ok == -1);

        // 3) strict decode rejections
        check("null rejected", UsbTransaction.decode(null) == null);
        check("empty rejected", UsbTransaction.decode("") == null);
        check("whitespace rejected", UsbTransaction.decode("   ") == null);
        check("newline rejected", UsbTransaction.decode(line + "\nextra") == null);
        check("too long rejected", UsbTransaction.decode(line + "x".repeat(600)) == null);
        check("unknown key rejected", UsbTransaction.decode(line + "|evil=1") == null);
        check("bad v rejected", UsbTransaction.decode(line.replace("v=1", "v=2")) == null);
        check("bad src rejected", UsbTransaction.decode(line.replace("src=auto", "src=x")) == null);
        check("metachar vol rejected", UsbTransaction.decode(line.replace("ABCD-1234", "a/b")) == null);
        check("space vol rejected", UsbTransaction.decode(line.replace("ABCD-1234", "a b")) == null);
        check("bad status rejected", UsbTransaction.decode(line.replace("completed", "done")) == null);
        check("nonnumeric ok rejected", UsbTransaction.decode(line.replace("ok=32", "ok=x")) == null);
        check("negative ok rejected", UsbTransaction.decode(line.replace("ok=32", "ok=-5")) == null);
        check("future ts rejected", UsbTransaction.decode(line.replace("ts=" + now, "ts=" + (now + 999999))) == null);
        check("missing src rejected", UsbTransaction.decode(line.replace("src=auto|", "")) == null);
        check("missing vol rejected", UsbTransaction.decode(line.replace("vol=ABCD-1234|", "")) == null);
        check("missing status rejected", UsbTransaction.decode(line.replace("status=completed|", "")) == null);
        check("missing ts rejected", UsbTransaction.decode(line.replace("ts=" + now + "|", "")) == null);
        check("empty value rejected", UsbTransaction.decode(line.replace("src=auto", "src=")) == null);
        check("double pipe rejected", UsbTransaction.decode(line + "||") == null);
        check("reason with = ok", UsbTransaction.decode(UsbTransaction.encode("auto","ABCD-1234","failed",-1,-1,"rejected=list",now,false)).reason.equals("rejected=list"));
        // exact daemon-format lines (shell writes ok=- for unknown)
        String daemonFail = "v=1|src=auto|vol=ABCD-1234|status=failed|ok=-|fail=-|reason=rejected=list|ts=" + now + "|consumed=0";
        UsbTransaction.Txn df = UsbTransaction.decode(daemonFail);
        check("daemon failed line", df != null && df.status.equals("failed") && df.ok == -1 && df.fail == -1 && df.reason.equals("rejected=list"));
        String daemonOk = "v=1|src=auto|vol=ABCD-1234|status=completed|ok=32|fail=0|reason=-|ts=" + now + "|consumed=0";
        UsbTransaction.Txn dOK = UsbTransaction.decode(daemonOk);
        check("daemon completed line", dOK != null && dOK.ok == 32 && dOK.fail == 0);
        check("daemon path reason", UsbTransaction.decode("v=1|src=auto|vol=ABCD-1234|status=failed|ok=-|fail=-|reason=rejected=path|ts=" + now + "|consumed=0").reason.equals("rejected=path"));

        // 4) isFresh
        check("fresh ok", UsbTransaction.isFresh(t, now));
        check("consumed not fresh", !UsbTransaction.isFresh(m, now));
        check("stale 25h not fresh", !UsbTransaction.isFresh(t, now + 90000));
        check("null not fresh", !UsbTransaction.isFresh(null, now));

        // 5) resolveStatus
        check("completed passes", UsbTransaction.resolveStatus(t, false, now).equals("completed"));
        UsbTransaction.Txn f = UsbTransaction.decode(UsbTransaction.encode("auto","ABCD-1234","failed",-1,-1,"rejected=list",now,false));
        check("failed passes", UsbTransaction.resolveStatus(f, true, now).equals("failed"));
        check("pending fresh stays pending", UsbTransaction.resolveStatus(m, true, now).equals("pending"));
        UsbTransaction.Txn pend = UsbTransaction.decode(UsbTransaction.encode("manual","ABCD-1234","pending",-1,-1,"-",now,false));
        check("pending stale + apply -> completed", UsbTransaction.resolveStatus(pend, true, now + 121).equals("completed"));
        check("pending stale no apply -> interrupted", UsbTransaction.resolveStatus(pend, false, now + 121).equals("interrupted"));
        check("resolveStatus null", UsbTransaction.resolveStatus(null, true, now) == null);

        // 6) KitPolicy regression (33-entry vetted list stays synchronized)
        check("vetted 33", KitPolicy.VETTED.length == 33);
        List<String> all = new ArrayList<>(Arrays.asList(KitPolicy.VETTED));
        check("all vetted", KitPolicy.isAllVetted(all));
        List<String> withExtra = new ArrayList<>(all); withExtra.add("com.evil.package");
        check("extra non-vetted", !KitPolicy.isAllVetted(withExtra));
        check("nonVetted found", KitPolicy.nonVetted(withExtra).contains("com.evil.package"));
        check("wellformed ok", KitPolicy.isAllWellFormed(all));
        check("metachar rejected", !KitPolicy.isAllWellFormed(Arrays.asList("com.a;rm -rf")));
        check("double dot rejected", !KitPolicy.isAllWellFormed(Arrays.asList("com..a")));
        check("leading dot rejected", !KitPolicy.isAllWellFormed(Arrays.asList(".com.a")));
        check("trailing dot rejected", !KitPolicy.isAllWellFormed(Arrays.asList("com.a.")));

        // 9) findLatest: newest record wins; legacy + fresh names both considered; none -> null
        java.io.File tmp = null;
        try {
            tmp = java.io.File.createTempFile("usbtxn-test", "dir");
            tmp.delete(); tmp.mkdirs();
            check("findLatest empty dir -> null", UsbTransaction.findLatest(tmp) == null);
            java.io.File a = new java.io.File(tmp, "usb-txn-100.json");
            writeF(a, "x"); a.setLastModified(1000L);
            java.io.File b = new java.io.File(tmp, "usb-txn-200.json");
            writeF(b, "y"); b.setLastModified(2000L);
            java.io.File legacy = new java.io.File(tmp, "usb-transaction.json");
            writeF(legacy, "z"); legacy.setLastModified(1500L);
            java.io.File other = new java.io.File(tmp, "config.json");
            writeF(other, "w"); other.setLastModified(9999L);   // must be ignored
            java.io.File newest = UsbTransaction.findLatest(tmp);
            check("findLatest picks newest (not config)", newest != null && newest.equals(b));
            b.delete();
            java.io.File next = UsbTransaction.findLatest(tmp);
            check("findLatest falls back to legacy when newer gone", next != null && next.equals(legacy));
            legacy.delete(); a.delete(); other.delete();
            check("findLatest null when all gone", UsbTransaction.findLatest(tmp) == null);
        } catch (Exception e) {
            check("findLatest no exception (" + e + ")", false);
        } finally {
            if (tmp != null) {
                java.io.File[] rem = tmp.listFiles();
                if (rem != null) for (java.io.File fl : rem) fl.delete();
                tmp.delete();
            }
        }

        // 10) readRecord: returns full content; null when absent; null when too large
        java.io.File rd;
        try {
            rd = java.io.File.createTempFile("usbtxn-rd", "txt");
            writeF(rd, "v=1|src=auto|vol=ABCD-1234|status=completed|ok=32|fail=0|reason=-|ts=1|consumed=0");
            String got = UsbTransaction.readRecord(rd, 1024);
            check("readRecord full content", got != null && got.startsWith("v=1|src=auto") && got.endsWith("consumed=0"));
            check("readRecord decodes", UsbTransaction.decode(got) != null);
            check("readRecord absent -> null", UsbTransaction.readRecord(new java.io.File(rd, "nope"), 1024) == null);
            check("readRecord null file -> null", UsbTransaction.readRecord(null, 1024) == null);
            check("readRecord too large -> null", UsbTransaction.readRecord(rd, 5) == null);
            rd.delete();
        } catch (Exception e) {
            check("readRecord no exception (" + e + ")", false);
        }

        // Consumption must read the full record and retain all fields.
        try {
            java.io.File receiptFile = java.io.File.createTempFile("usbtxn-consume", ".json");
            String original = UsbTransaction.encode("auto", "ABCD-1234", "completed", 32, 0, "-", 123, false);
            writeF(receiptFile, original);
            check("consume succeeds", UsbTransaction.consumeRecord(receiptFile));
            UsbTransaction.Txn consumed = UsbTransaction.decode(UsbTransaction.readRecord(receiptFile, 1024));
            check("consumed flag persisted", consumed != null && consumed.consumed);
            check("consumed fields preserved", consumed != null && consumed.vol.equals("ABCD-1234") && consumed.ok == 32 && consumed.ts == 123);
            check("consume is idempotent", UsbTransaction.consumeRecord(receiptFile));
            writeF(receiptFile, "invalid");
            check("invalid consume rejected", !UsbTransaction.consumeRecord(receiptFile));
            check("invalid receipt untouched", "invalid".equals(UsbTransaction.readRecord(receiptFile, 1024)));
            String longText = new String(new char[700]).replace('\0', 'x');
            writeF(receiptFile, longText);
            check("multi-buffer exact bytes", longText.equals(UsbTransaction.readRecord(receiptFile, 1024)));
            check("bounded limit enforced", UsbTransaction.readRecord(receiptFile, 699) == null);
            receiptFile.delete();
            check("pending filename ignored", !UsbTransaction.isRecordName("usb-txn-123.json.pending"));
            check("archived filename ignored", !UsbTransaction.isRecordName("usb-txn-123.json.regression-hold"));
            check("record name accepted", UsbTransaction.isRecordName("usb-txn-123.json"));
            check("non-numeric timestamp ignored", !UsbTransaction.isRecordName("usb-txn-bad.json"));
        } catch (Exception ex) { check("consume/read tests no exception " + ex, false); }

        System.out.println("PASS=" + pass + " FAIL=" + fail);
        if (fail > 0) System.exit(1);
    }
}
